export type CategoryId = 'crepe' | 'satin' | 'linen' | 'silk' | 'jacquard' | 'velvet' | 'poplin';

export interface FabricCategory {
  id: CategoryId;
  name: string;
  enName: string;
  description: string;
  image: string;
  count: number;
}

export type FabricPattern = 'ساده' | 'طرح‌دار' | 'ژاکارد و برجسته' | 'طلاکوب' | 'راه‌راه و چهارخانه' | 'پلیسه';

export interface ColorOption {
  name: string;
  hex: string;
}

export interface FabricProduct {
  id: string; // e.g. "AV-101"
  name: string;
  category: CategoryId;
  categoryName: string;
  pattern: FabricPattern;
  pricePerMeter: number; // in Tomans
  oldPricePerMeter?: number;
  widthCm: number; // e.g. 150
  images: string[];
  colors: ColorOption[];
  tags: ('جدید' | 'پرفروش' | 'پیشنهاد ویژه' | 'تخفیفدار')[];
  inStock: boolean;
  
  // Specifications
  specs: {
    material: string; // جنس پارچه: مثلاً ابریشم و استات، ۱۰۰٪ کتان پنبه
    width: string; // عرض: ۱۵۰ سانتی‌متر
    suitableFor: string[]; // مناسب برای: مانتو، شومیز، لباس مجلسی، شلوار
    season: string[]; // بهاره، تابستانه، چهارفصل، پاییزه
    stretch: string;
    drape: string;
    sheerness: string;
    wrinkleResistance: string;
    shrinkage: string;
    careInstructions: string; // نحوه شستشو و اتوکشی
  };
  
  description: string;
  recommendedGarments: {
    name: string;
    suggestedMeters: string;
  }[];
}

export interface OrderStep {
  step: number;
  title: string;
  description: string;
  iconName: string;
  tip?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'سفارش' | 'ارسال' | 'پارچه' | 'مرجوعی';
}

export type PageView = 'home' | 'products' | 'product-detail' | 'order-guide' | 'about' | 'contact';

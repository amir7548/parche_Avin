import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { FabricProduct, PageView, CategoryId } from '../types';
import { PRODUCTS } from '../data/products';

interface ConfigContextType {
  currentPage: PageView;
  setCurrentPage: (page: PageView) => void;
  selectedProduct: FabricProduct | null;
  setSelectedProduct: (product: FabricProduct | null) => void;
  openProductDetail: (product: FabricProduct) => void;
  
  // Telegram Bot integration
  botUsername: string;
  setBotUsername: (username: string) => void;
  getTelegramDeepLink: (productId?: string) => string;
  openTelegramBot: (productId?: string) => void;
  
  // Filtering & Global Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategoryFilter: CategoryId | 'all';
  setSelectedCategoryFilter: (cat: CategoryId | 'all') => void;
  
  // Favorites
  favorites: string[];
  toggleFavorite: (productId: string) => void;
  isFavorite: (productId: string) => boolean;
  
  // Toast notifications
  toastMessage: string | null;
  showToast: (msg: string) => void;
  
  // Calculator modal toggle
  isCalculatorOpen: boolean;
  setIsCalculatorOpen: (open: boolean) => void;
  
  // Bot Settings modal toggle
  isBotConfigOpen: boolean;
  setIsBotConfigOpen: (open: boolean) => void;
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

export const ConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [selectedProduct, setSelectedProduct] = useState<FabricProduct | null>(null);
  
  // Telegram bot username - customizable (defaults to avin_textile_bot)
  const [botUsername, setBotUsernameState] = useState<string>(() => {
    return localStorage.getItem('avin_bot_username') || 'avin_textile_bot';
  });
  
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<CategoryId | 'all'>('all');
  
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('avin_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState<boolean>(false);
  const [isBotConfigOpen, setIsBotConfigOpen] = useState<boolean>(false);

  const setBotUsername = (username: string) => {
    const clean = username.replace(/^@/, '').trim();
    setBotUsernameState(clean);
    localStorage.setItem('avin_bot_username', clean);
    showToast(`شناسه ربات تلگرام به @${clean} تغییر یافت`);
  };

  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const next = prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId];
      try {
        localStorage.setItem('avin_favorites', JSON.stringify(next));
      } catch (e) {
        console.error(e);
      }
      return next;
    });
  };

  const isFavorite = (productId: string) => favorites.includes(productId);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  const getTelegramDeepLink = (productId?: string) => {
    const cleanBot = botUsername.replace(/^@/, '').trim() || 'avin_textile_bot';
    if (productId) {
      // Direct deep link format: https://t.me/{BOT_USERNAME}?start=p_{PRODUCT_ID}
      return `https://t.me/${cleanBot}?start=p_${encodeURIComponent(productId)}`;
    }
    return `https://t.me/${cleanBot}`;
  };

  const openTelegramBot = (productId?: string) => {
    const link = getTelegramDeepLink(productId);
    window.open(link, '_blank', 'noopener,noreferrer');
    if (productId) {
      showToast(`در حال هدایت به ربات تلگرام برای پارچه ${productId}...`);
    } else {
      showToast('در حال باز کردن ربات تلگرام پارچه آوین...');
    }
  };

  const openProductDetail = (product: FabricProduct) => {
    setSelectedProduct(product);
    setCurrentPage('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  const value = useMemo(() => ({
    currentPage,
    setCurrentPage,
    selectedProduct,
    setSelectedProduct,
    openProductDetail,
    botUsername,
    setBotUsername,
    getTelegramDeepLink,
    openTelegramBot,
    searchQuery,
    setSearchQuery,
    selectedCategoryFilter,
    setSelectedCategoryFilter,
    favorites,
    toggleFavorite,
    isFavorite,
    toastMessage,
    showToast,
    isCalculatorOpen,
    setIsCalculatorOpen,
    isBotConfigOpen,
    setIsBotConfigOpen
  }), [
    currentPage,
    selectedProduct,
    botUsername,
    searchQuery,
    selectedCategoryFilter,
    favorites,
    toastMessage,
    isCalculatorOpen,
    isBotConfigOpen
  ]);

  return (
    <ConfigContext.Provider value={value}>
      {children}
    </ConfigContext.Provider>
  );
};

export const useConfig = () => {
  const context = useContext(ConfigContext);
  if (!context) {
    throw new Error('useConfig must be used within a ConfigProvider');
  }
  return context;
};

// Utility for Persian numbers and price formatters

export function toPersianDigits(num: number | string): string {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num
    .toString()
    .replace(/\d/g, (x) => farsiDigits[parseInt(x, 10)]);
}

export function formatPrice(price: number): string {
  const formatted = price.toLocaleString('fa-IR');
  return `${formatted} تومان`;
}

export function formatPricePerMeter(price: number): string {
  const formatted = price.toLocaleString('fa-IR');
  return `${formatted} تومان / هر متر`;
}

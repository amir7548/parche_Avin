import React from 'react';
import { ConfigProvider, useConfig } from './context/ConfigContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Toast } from './components/Toast';
import { FabricCalculatorModal } from './components/FabricCalculatorModal';
import { TelegramBotConfigModal } from './components/TelegramBotConfigModal';

// Pages
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { OrderGuidePage } from './pages/OrderGuidePage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';

const AppContent: React.FC = () => {
  const { currentPage } = useConfig();

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAF8] text-[#1F1F1F]">
      {/* Top sticky navbar */}
      <Header />

      {/* Main Page Content View */}
      <main className="flex-1">
        {currentPage === 'home' && <HomePage />}
        {currentPage === 'products' && <ProductsPage />}
        {currentPage === 'product-detail' && <ProductDetailPage />}
        {currentPage === 'order-guide' && <OrderGuidePage />}
        {currentPage === 'about' && <AboutPage />}
        {currentPage === 'contact' && <ContactPage />}
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Navigation Bar */}
      <MobileBottomNav />

      {/* Modals & Overlays */}
      <FabricCalculatorModal />
      <TelegramBotConfigModal />
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <ConfigProvider>
      <AppContent />
    </ConfigProvider>
  );
}

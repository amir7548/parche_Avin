import React, { useState } from 'react';
import { useConfig } from '../context/ConfigContext';
import { Settings2, X, Send, Check, Copy, ExternalLink, Bot } from 'lucide-react';

export const TelegramBotConfigModal: React.FC = () => {
  const { 
    isBotConfigOpen, 
    setIsBotConfigOpen, 
    botUsername, 
    setBotUsername, 
    getTelegramDeepLink,
    showToast 
  } = useConfig();

  const [inputVal, setInputVal] = useState(botUsername);
  const [copied, setCopied] = useState(false);

  if (!isBotConfigOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setBotUsername(inputVal);
    setIsBotConfigOpen(false);
  };

  const sampleDeepLink = getTelegramDeepLink('AV-101');

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(sampleDeepLink);
    setCopied(true);
    showToast('لینک نمونه تلگرام کپی شد');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="telegram-config-modal"
        className="relative bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-[#E7E7E2] p-6 text-right"
      >
        <div className="flex items-center justify-between border-b border-[#E7E7E2] pb-4 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#1F1F1F] text-white rounded-lg">
              <Bot size={20} />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1F1F1F]">تنظیمات ربات تلگرام آوین</h3>
              <p className="text-xs text-[#7A7A7A]">شناسه ربات برای هدایت کلیک‌های دکمه سفارش</p>
            </div>
          </div>
          <button
            onClick={() => setIsBotConfigOpen(false)}
            className="p-1 text-[#7A7A7A] hover:text-[#1F1F1F] rounded-lg transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#1F1F1F] mb-1.5">
              آیدی ربات تلگرام (بدون @ یا با @):
            </label>
            <div className="relative">
              <input
                id="bot-username-input"
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                dir="ltr"
                placeholder="avin_textile_bot"
                className="w-full px-3 py-2 text-sm font-mono bg-[#FAFAF8] border border-[#E7E7E2] focus:border-[#C97C7C] focus:bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-[#C97C7C]"
              />
              <span className="absolute left-3 top-2.5 text-xs text-[#7A7A7A] font-mono">@</span>
            </div>
            <p className="text-[11px] text-[#7A7A7A] mt-1">
              تمام دکمه‌های «ثبت سفارش در ربات تلگرام» به این آیدی متصل خواهند شد.
            </p>
          </div>

          {/* Deep link preview */}
          <div className="bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl p-3.5 space-y-2">
            <span className="text-xs font-semibold text-[#1F1F1F] block">
              فرمت Deep Link تولید شده برای محصولات:
            </span>
            <div className="flex items-center justify-between gap-2 bg-white px-2.5 py-1.5 rounded-lg border border-[#E7E7E2]">
              <code className="text-[11px] text-[#C97C7C] font-mono dir-ltr truncate">
                {sampleDeepLink}
              </code>
              <button
                type="button"
                onClick={handleCopyLink}
                className="p-1 text-[#7A7A7A] hover:text-[#1F1F1F] rounded shrink-0 cursor-pointer"
                title="کپی لینک"
              >
                {copied ? <Check size={15} className="text-green-600" /> : <Copy size={15} />}
              </button>
            </div>
            <p className="text-[10px] text-[#7A7A7A]">
              هنگامی که کاربر روی هر پارچه کلیک می‌کند، پارامتر <code>start=p_PRODUCT_ID</code> به ربات ارسال می‌شود.
            </p>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="submit"
              className="flex-1 py-2.5 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-xs sm:text-sm font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              ذخیره و اعمال
            </button>
            <a
              href={getTelegramDeepLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 bg-[#1F1F1F] hover:bg-black text-white text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer no-underline"
            >
              <ExternalLink size={14} />
              <span>تست در تلگرام</span>
            </a>
          </div>
        </form>
      </div>
    </div>
  );
};

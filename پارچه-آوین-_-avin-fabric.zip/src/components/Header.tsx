import React, { useState } from 'react';
import { useConfig } from '../context/ConfigContext';
import { PageView } from '../types';
import { 
  Search, 
  Send, 
  Ruler, 
  Menu, 
  X, 
  Heart, 
  Settings2,
  Sparkles
} from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';

export const Header: React.FC = () => {
  const { 
    currentPage, 
    setCurrentPage, 
    searchQuery, 
    setSearchQuery, 
    favorites,
    botUsername,
    openTelegramBot,
    setIsCalculatorOpen,
    setIsBotConfigOpen
  } = useConfig();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const navItems: { id: PageView; label: string }[] = [
    { id: 'home', label: 'خانه' },
    { id: 'products', label: 'پارچه‌ها' },
    { id: 'order-guide', label: 'راهنمای سفارش' },
    { id: 'about', label: 'درباره ما' },
    { id: 'contact', label: 'تماس با ما' }
  ];

  const handleNavClick = (page: PageView) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setCurrentPage('products');
      setIsSearchOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAFAF8]/90 backdrop-blur-md border-b border-[#E7E7E2] transition-all">
      {/* Top micro announcement bar */}
      <div className="bg-[#1F1F1F] text-[#FAFAF8] text-xs py-1.5 px-4 text-center flex items-center justify-center gap-2 font-normal">
        <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#C97C7C] animate-pulse"></span>
        <span>ثبت سفارش و مشاوره فوری پارچه زنانه در ربات تلگرام</span>
        <span className="text-[#C97C7C] font-mono text-[11px] dir-ltr inline-block mr-1">@{botUsername}</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 sm:h-20">
          
          {/* Right side (in RTL): Brand Logo */}
          <div className="flex items-center gap-8">
            <button 
              id="header-logo-btn"
              onClick={() => handleNavClick('home')} 
              className="text-right group focus:outline-none flex items-center gap-3 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-[#C97C7C] text-white flex items-center justify-center font-bold text-xl shadow-xs transition-transform group-hover:scale-105">
                آ
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-black tracking-tight text-[#1F1F1F] leading-none">
                  پارچه آوین
                </span>
                <span className="text-[10px] tracking-widest text-[#7A7A7A] uppercase font-light mt-1">
                  AVIN TEXTILE & FABRICS
                </span>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center gap-1 lg:gap-2">
              {navItems.map((item) => {
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-link-${item.id}`}
                    onClick={() => handleNavClick(item.id)}
                    className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                      isActive 
                        ? 'text-[#C97C7C] bg-[#C97C7C]/10 font-semibold' 
                        : 'text-[#1F1F1F] hover:text-[#C97C7C] hover:bg-[#FAFAF8]'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Left side (in RTL): Actions (Search, Calculator, Telegram CTA) */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Search Toggle / Form */}
            <div className="relative">
              {isSearchOpen ? (
                <form onSubmit={handleSearchSubmit} className="flex items-center">
                  <input
                    id="header-search-input"
                    type="text"
                    autoFocus
                    placeholder="جستجوی نام یا کد پارچه..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-44 sm:w-64 pl-8 pr-3 py-1.5 text-xs sm:text-sm bg-white border border-[#C97C7C] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#C97C7C]"
                  />
                  <button 
                    type="button" 
                    onClick={() => setIsSearchOpen(false)}
                    className="absolute left-2 text-[#7A7A7A] hover:text-[#1F1F1F]"
                  >
                    <X size={16} />
                  </button>
                </form>
              ) : (
                <button
                  id="header-search-btn"
                  onClick={() => setIsSearchOpen(true)}
                  aria-label="جستجو"
                  className="p-2 rounded-lg text-[#1F1F1F] hover:bg-[#EFEFEA] transition-colors cursor-pointer"
                  title="جستجوی پارچه‌ها"
                >
                  <Search size={20} />
                </button>
              )}
            </div>

            {/* Fabric Yardage Calculator Trigger */}
            <button
              id="header-calculator-btn"
              onClick={() => setIsCalculatorOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1F1F1F] bg-white border border-[#E7E7E2] hover:border-[#C97C7C] rounded-lg transition-all shadow-2xs hover:text-[#C97C7C] cursor-pointer"
              title="محاسبه متراژ پارچه مورد نیاز"
            >
              <Ruler size={16} className="text-[#C97C7C]" />
              <span>محاسبه‌گر متراژ</span>
            </button>

            {/* Telegram Bot Username Settings Trigger */}
            <button
              id="header-settings-btn"
              onClick={() => setIsBotConfigOpen(true)}
              aria-label="تنظیمات ربات تلگرام"
              className="p-2 rounded-lg text-[#7A7A7A] hover:text-[#1F1F1F] hover:bg-[#EFEFEA] transition-colors cursor-pointer"
              title="تنظیمات ربات تلگرام"
            >
              <Settings2 size={19} />
            </button>

            {/* Telegram CTA Button (Direct Bot Link) */}
            <button
              id="header-telegram-cta"
              onClick={() => openTelegramBot()}
              className="flex items-center gap-2 px-3.5 sm:px-4 py-2 sm:py-2.5 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-xs sm:text-sm font-medium rounded-lg shadow-xs transition-all transform active:scale-95 cursor-pointer"
            >
              <Send size={16} className="rotate-45" />
              <span className="hidden sm:inline">ربات تلگرام آوین</span>
              <span className="sm:hidden">تلگرام</span>
            </button>

            {/* Mobile Hamburger Toggle */}
            <button
              id="header-mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#1F1F1F] hover:bg-[#EFEFEA] rounded-lg transition-colors cursor-pointer"
              aria-label="منو"
            >
              {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E7E7E2] bg-[#FAFAF8] px-4 pt-3 pb-6 space-y-3 shadow-md animate-in slide-in-from-top-2 duration-200">
          <div className="flex flex-col space-y-1">
            {navItems.map((item) => {
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-link-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full text-right px-4 py-2.5 rounded-lg text-base font-medium transition-colors ${
                    isActive 
                      ? 'text-[#C97C7C] bg-[#C97C7C]/10 font-semibold' 
                      : 'text-[#1F1F1F] hover:bg-[#EFEFEA]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#E7E7E2] flex flex-col gap-2">
            <button
              id="mobile-calculator-btn"
              onClick={() => {
                setIsCalculatorOpen(true);
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between px-4 py-2.5 bg-white border border-[#E7E7E2] rounded-lg text-sm text-[#1F1F1F]"
            >
              <div className="flex items-center gap-2">
                <Ruler size={17} className="text-[#C97C7C]" />
                <span>محاسبه‌گر هوشمند متراژ پارچه</span>
              </div>
              <Sparkles size={15} className="text-[#C97C7C]" />
            </button>

            <button
              id="mobile-telegram-direct-btn"
              onClick={() => {
                openTelegramBot();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-[#1F1F1F] text-white rounded-lg text-sm font-medium"
            >
              <Send size={16} />
              <span>ثبت سفارش در ربات تلگرام (@{botUsername})</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

import React from 'react';
import { FabricProduct } from '../types';
import { useConfig } from '../context/ConfigContext';
import { Send, Eye, Heart, Ruler, CheckCircle2 } from 'lucide-react';
import { formatPrice, toPersianDigits } from '../utils/formatters';

interface ProductCardProps {
  product: FabricProduct;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { 
    openProductDetail, 
    openTelegramBot, 
    getTelegramDeepLink, 
    toggleFavorite, 
    isFavorite,
    showToast,
    botUsername
  } = useConfig();

  const favorite = isFavorite(product.id);
  const telegramLink = getTelegramDeepLink(product.id);

  const handleCopyCode = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(product.id);
    showToast(`کد پارچه ${product.id} کپی شد`);
  };

  return (
    <div 
      id={`product-card-${product.id}`}
      className="group relative bg-white border border-[#E7E7E2] hover:border-[#C97C7C]/60 rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg flex flex-col h-full"
    >
      {/* Image Container with Badges and Overlays */}
      <div 
        onClick={() => openProductDetail(product)}
        className="relative aspect-4/5 w-full bg-[#EFEFEA] overflow-hidden cursor-pointer"
      >
        <img
          src={product.images[0]}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          {product.tags.map((tag, idx) => (
            <span
              key={idx}
              className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full backdrop-blur-md shadow-xs ${
                tag === 'جدید'
                  ? 'bg-[#1F1F1F]/80 text-white'
                  : tag === 'پرفروش'
                  ? 'bg-[#C97C7C] text-white'
                  : 'bg-white/90 text-[#1F1F1F]'
              }`}
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Product Code Badge */}
        <div 
          onClick={handleCopyCode}
          title="برای کپی کد کلیک کنید"
          className="absolute bottom-2.5 right-2.5 bg-black/75 hover:bg-black text-white text-[11px] font-mono px-2 py-0.5 rounded-md backdrop-blur-xs transition-colors flex items-center gap-1 z-10 cursor-pointer"
        >
          <span>کد: {product.id}</span>
        </div>

        {/* Bookmark / Favorite Button */}
        <button
          id={`fav-btn-${product.id}`}
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(product.id);
          }}
          aria-label="نشان کردن"
          className={`absolute top-2.5 left-2.5 p-2 rounded-full transition-all backdrop-blur-md z-10 ${
            favorite 
              ? 'bg-[#C97C7C] text-white' 
              : 'bg-white/80 hover:bg-white text-[#1F1F1F]'
          }`}
        >
          <Heart size={16} className={favorite ? 'fill-white' : ''} />
        </button>

        {/* Quick hover overlay hint */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="bg-white/95 text-[#1F1F1F] text-xs font-medium px-3 py-1.5 rounded-full shadow-sm flex items-center gap-1.5">
            <Eye size={14} className="text-[#C97C7C]" />
            مشاهده جزئیات و مشخصات
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Pattern */}
          <div className="flex items-center justify-between text-xs text-[#7A7A7A] mb-1.5">
            <span>{product.categoryName}</span>
            <span className="text-[11px] bg-[#FAFAF8] px-2 py-0.5 rounded border border-[#E7E7E2]">
              {product.pattern}
            </span>
          </div>

          {/* Product Title */}
          <h3 
            onClick={() => openProductDetail(product)}
            className="text-base font-bold text-[#1F1F1F] hover:text-[#C97C7C] transition-colors line-clamp-1 cursor-pointer mb-2"
            title={product.name}
          >
            {product.name}
          </h3>

          {/* 2 Key Features / Specs */}
          <div className="space-y-1 text-xs text-[#7A7A7A] mb-3">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C97C7C]"></span>
              <span>عرض: {product.specs.width}</span>
            </div>
            <div className="flex items-center gap-1.5 line-clamp-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C97C7C]"></span>
              <span className="truncate">مناسب: {product.specs.suitableFor.slice(0, 2).join('، ')}</span>
            </div>
          </div>

          {/* Color Swatches */}
          {product.colors && product.colors.length > 0 && (
            <div className="flex items-center gap-1.5 mb-4">
              <span className="text-[11px] text-[#7A7A7A]">رنگ‌ها:</span>
              <div className="flex items-center gap-1">
                {product.colors.map((c, i) => (
                  <span
                    key={i}
                    title={c.name}
                    className="w-3.5 h-3.5 rounded-full border border-black/15 shadow-2xs inline-block"
                    style={{ backgroundColor: c.hex }}
                  />
                ))}
                {product.colors.length > 4 && (
                  <span className="text-[10px] text-[#7A7A7A]">+{toPersianDigits(product.colors.length - 4)}</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Price & Primary CTA */}
        <div className="pt-3 border-t border-[#E7E7E2] space-y-3">
          <div className="flex items-baseline justify-between">
            <span className="text-xs text-[#7A7A7A]">قیمت هر متر:</span>
            <div className="text-right">
              {product.oldPricePerMeter && (
                <span className="text-xs text-[#7A7A7A] line-through ml-2">
                  {formatPrice(product.oldPricePerMeter)}
                </span>
              )}
              <span className="text-sm sm:text-base font-extrabold text-[#1F1F1F]">
                {formatPrice(product.pricePerMeter)}
              </span>
            </div>
          </div>

          {/* Primary CTA: "ثبت سفارش در ربات تلگرام" */}
          <a
            id={`product-telegram-cta-${product.id}`}
            href={telegramLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => {
              // Track or show feedback
              showToast(`در حال اتصال به ربات تلگرام برای پارچه کد ${product.id}`);
            }}
            className="w-full py-2.5 px-3 bg-[#C97C7C] hover:bg-[#b66a6a] active:bg-[#a35c5c] text-white text-xs sm:text-sm font-semibold rounded-lg shadow-xs transition-all flex items-center justify-center gap-2 group/btn cursor-pointer no-underline text-center"
          >
            <Send size={15} className="rotate-45 transition-transform group-hover/btn:translate-x-[-2px] group-hover/btn:translate-y-[-2px]" />
            <span>ثبت سفارش در ربات تلگرام</span>
          </a>
        </div>
      </div>
    </div>
  );
};

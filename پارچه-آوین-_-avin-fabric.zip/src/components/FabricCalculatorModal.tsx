import React, { useState } from 'react';
import { useConfig } from '../context/ConfigContext';
import { Ruler, X, Sparkles, Check, Send, Info } from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';

interface GarmentPattern {
  id: string;
  name: string;
  category: string;
  baseMeters: number; // For width 150cm
  description: string;
  tips: string;
}

const GARMENTS: GarmentPattern[] = [
  {
    id: 'coat-short',
    name: 'مانتو یا کت کوتاه کتی',
    category: 'مانتو و کت',
    baseMeters: 1.6,
    description: 'قد کت تا روی باسن (۷۰ تا ۸۰ سانتی‌متر)',
    tips: 'برای آسترکشی کامل، ۱.۵ متر آستری تافته یا سارژ جداگانه نیاز است.'
  },
  {
    id: 'coat-long',
    name: 'مانتو بلند یا عبایی',
    category: 'مانتو و کت',
    baseMeters: 2.3,
    description: 'قد مانتو تا زیر زانو یا مچ پا (۱۱۰ تا ۱۲۵ سانتی‌متر)',
    tips: 'در مدل‌های چین‌دار یا دراپه، ۲۰ الی ۳۰ سانتی‌متر به متراژ اضافه کنید.'
  },
  {
    id: 'blouse-simple',
    name: 'شومیز آستین بلند استاندارد',
    category: 'شومیز و تاپ',
    baseMeters: 1.4,
    description: 'قد شومیز ۶۵ سانتی‌متر با آستین مچی',
    tips: 'برای آستین‌های پفکی مزونی یا یقه پاپیونی بزرگ، ۱.۷ متر پیشنهاد می‌شود.'
  },
  {
    id: 'pants-classic',
    name: 'شلوار راسته یا بگ زنانه',
    category: 'شلوار و دامن',
    baseMeters: 1.15,
    description: 'قد شلوار ۱۰۰ تا ۱۰۵ سانتی‌متر',
    tips: 'برای سایزهای ۴۶ به بالا یا مدل‌های پیلی‌دار فراوان، ۱.۴ متر در نظر بگیرید.'
  },
  {
    id: 'skirt-flare',
    name: 'دامن نیم کلوش یا فون',
    category: 'شلوار و دامن',
    baseMeters: 1.8,
    description: 'قد دامن ۸۵ تا ۹۵ سانتی‌متر',
    tips: 'برای دامن تمام کلوش بدون درز، ۲.۵ متر پارچه با عرض ۱۵۰ نیاز است.'
  },
  {
    id: 'dress-maxi',
    name: 'پیراهن مجلسی ماکسی بلند',
    category: 'مجلسی و پیراهن',
    baseMeters: 2.8,
    description: 'قد پیراهن تا روی زمین با آستین ساده',
    tips: 'اگر دامن پیراهن والان‌دار یا چندطبقه است، حداقل ۳.۵ متر پارچه لازم دارید.'
  },
  {
    id: 'suit-set',
    name: 'کت و شلوار زنانه مجلسی (ست)',
    category: 'مانتو و کت',
    baseMeters: 3.0,
    description: 'ست کامل کت و شلوار با قد استاندارد',
    tips: 'یکی از پرطرفدارترین دوخت‌ها با پارچه‌های کرپ مازراتی و ژاکارد آوین.'
  }
];

export const FabricCalculatorModal: React.FC = () => {
  const { isCalculatorOpen, setIsCalculatorOpen, openTelegramBot } = useConfig();
  
  const [selectedGarmentId, setSelectedGarmentId] = useState<string>('coat-short');
  const [userHeight, setUserHeight] = useState<'petite' | 'regular' | 'tall'>('regular');
  const [userSize, setUserSize] = useState<'standard' | 'plussize'>('standard');
  const [hasLining, setHasLining] = useState<boolean>(false);

  if (!isCalculatorOpen) return null;

  const garment = GARMENTS.find(g => g.id === selectedGarmentId) || GARMENTS[0];

  // Calculate adjusted meters
  let calculatedMeters = garment.baseMeters;
  if (userHeight === 'tall') calculatedMeters += 0.2;
  if (userHeight === 'petite') calculatedMeters -= 0.1;
  if (userSize === 'plussize') calculatedMeters += 0.3;

  // Round to nearest 0.05
  calculatedMeters = Math.round(calculatedMeters * 20) / 20;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="fabric-calculator-modal"
        className="relative bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#E7E7E2] p-6 sm:p-7 text-right"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E7E7E2] pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#C97C7C]/15 rounded-lg text-[#C97C7C]">
              <Ruler size={22} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#1F1F1F]">محاسبه‌گر متراژ پارچه زنانه</h3>
              <p className="text-xs text-[#7A7A7A]">محاسبه هوشمند بر مبنای پارچه‌های عرض ۱۵۰ سانتی‌متر</p>
            </div>
          </div>
          <button
            id="close-calculator-btn"
            onClick={() => setIsCalculatorOpen(false)}
            className="p-1.5 text-[#7A7A7A] hover:text-[#1F1F1F] hover:bg-[#FAFAF8] rounded-lg transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Step 1: Select Garment */}
        <div className="space-y-4 mb-6">
          <label className="block text-xs font-bold text-[#1F1F1F]">
            ۱. نوع لباس مورد نظر را انتخاب کنید:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {GARMENTS.map(item => (
              <button
                key={item.id}
                id={`garment-btn-${item.id}`}
                onClick={() => setSelectedGarmentId(item.id)}
                className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedGarmentId === item.id
                    ? 'border-[#C97C7C] bg-[#C97C7C]/10 ring-1 ring-[#C97C7C]'
                    : 'border-[#E7E7E2] hover:border-[#C97C7C]/40 bg-white'
                }`}
              >
                <div className="font-semibold text-xs text-[#1F1F1F] mb-0.5">{item.name}</div>
                <div className="text-[11px] text-[#7A7A7A]">{item.description}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Step 2: Custom Adjustments (Height & Size) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6 pt-4 border-t border-[#E7E7E2]">
          <div>
            <label className="block text-xs font-bold text-[#1F1F1F] mb-2">
              ۲. قد شما:
            </label>
            <div className="flex gap-2">
              {[
                { id: 'petite', label: 'کوتاه (زیر ۱۶۰)' },
                { id: 'regular', label: 'متوسط (۱۶۰-۱۷۰)' },
                { id: 'tall', label: 'بلند (بالای ۱۷۰)' }
              ].map(h => (
                <button
                  key={h.id}
                  onClick={() => setUserHeight(h.id as any)}
                  className={`flex-1 py-1.5 px-1 text-[11px] rounded-lg border font-medium cursor-pointer ${
                    userHeight === h.id 
                      ? 'bg-[#1F1F1F] text-white border-[#1F1F1F]' 
                      : 'bg-[#FAFAF8] text-[#1F1F1F] border-[#E7E7E2]'
                  }`}
                >
                  {h.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1F1F1F] mb-2">
              ۳. رده سایزی:
            </label>
            <div className="flex gap-2">
              {[
                { id: 'standard', label: 'سایز استاندارد (۳۶ تا ۴۴)' },
                { id: 'plussize', label: 'پلاس‌سایز (۴۶ به بالا)' }
              ].map(s => (
                <button
                  key={s.id}
                  onClick={() => setUserSize(s.id as any)}
                  className={`flex-1 py-1.5 px-1 text-[11px] rounded-lg border font-medium cursor-pointer ${
                    userSize === s.id 
                      ? 'bg-[#1F1F1F] text-white border-[#1F1F1F]' 
                      : 'bg-[#FAFAF8] text-[#1F1F1F] border-[#E7E7E2]'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Result Highlight Box */}
        <div className="bg-[#F9EFEF] border border-[#C97C7C]/30 rounded-xl p-4 sm:p-5 mb-5 text-center">
          <span className="text-xs text-[#7A7A7A] block mb-1">متراژ تخمینی مورد نیاز شما:</span>
          <div className="text-2xl sm:text-3xl font-black text-[#C97C7C] tracking-tight">
            {toPersianDigits(calculatedMeters.toFixed(2).replace(/\.00$/, ''))} متر
          </div>
          <span className="text-[11px] text-[#7A7A7A] mt-1 block">با احتساب عرض ۱۵۰ سانتی‌متر پارچه</span>

          <div className="mt-3 pt-3 border-t border-[#C97C7C]/20 flex items-start gap-2 text-right text-xs text-[#1F1F1F]/80">
            <Info size={16} className="text-[#C97C7C] shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              <strong className="text-[#1F1F1F]">نکته تخصصی آوین:</strong> {garment.tips}
            </p>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <button
            id="calculator-telegram-consult-btn"
            onClick={() => {
              openTelegramBot();
              setIsCalculatorOpen(false);
            }}
            className="flex-1 py-2.5 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-xs sm:text-sm font-semibold rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Send size={15} className="rotate-45" />
            <span>مشاوره دقیق‌تر و تایید متراژ در تلگرام</span>
          </button>
          <button
            onClick={() => setIsCalculatorOpen(false)}
            className="py-2.5 px-4 bg-white border border-[#E7E7E2] text-xs sm:text-sm font-medium rounded-lg text-[#1F1F1F] hover:bg-[#FAFAF8] cursor-pointer"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { useConfig } from '../context/ConfigContext';
import { PageView } from '../types';
import { Home, Layers, Send, HelpCircle, Phone } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { currentPage, setCurrentPage, openTelegramBot, botUsername } = useConfig();

  const items = [
    { id: 'home' as PageView, label: 'خانه', icon: Home },
    { id: 'products' as PageView, label: 'پارچه‌ها', icon: Layers },
    { id: 'telegram-direct' as any, label: 'ربات تلگرام', icon: Send, isSpecial: true },
    { id: 'order-guide' as PageView, label: 'راهنما', icon: HelpCircle },
    { id: 'contact' as PageView, label: 'تماس', icon: Phone }
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-[#E7E7E2] px-2 py-1.5 shadow-lg">
      <div className="flex items-center justify-around">
        {items.map(item => {
          if (item.isSpecial) {
            return (
              <button
                key="telegram"
                id="mobile-nav-telegram-bot"
                onClick={() => openTelegramBot()}
                className="flex flex-col items-center justify-center -mt-4 bg-[#C97C7C] text-white p-2.5 rounded-full shadow-md transition-transform active:scale-95 cursor-pointer"
              >
                <Send size={18} className="rotate-45" />
                <span className="text-[9px] font-bold mt-0.5">تلگرام</span>
              </button>
            );
          }

          const isActive = currentPage === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              id={`mobile-bottom-${item.id}`}
              onClick={() => setCurrentPage(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg transition-colors cursor-pointer ${
                isActive ? 'text-[#C97C7C] font-bold' : 'text-[#7A7A7A] hover:text-[#1F1F1F]'
              }`}
            >
              <Icon size={18} />
              <span className="text-[10px] mt-1">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

import React from 'react';
import { useConfig } from '../context/ConfigContext';
import { Sparkles, CheckCircle2 } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toastMessage } = useConfig();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-20 sm:bottom-8 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200 pointer-events-none">
      <div className="bg-[#1F1F1F]/95 text-white backdrop-blur-md px-4 py-2.5 rounded-xl shadow-xl text-xs sm:text-sm font-medium flex items-center gap-2 border border-white/10">
        <CheckCircle2 size={16} className="text-[#C97C7C]" />
        <span>{toastMessage}</span>
      </div>
    </div>
  );
};

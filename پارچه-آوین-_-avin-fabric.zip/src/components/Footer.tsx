import React from 'react';
import { useConfig } from '../context/ConfigContext';
import { 
  Send, 
  Instagram, 
  Phone, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Truck, 
  Sparkles,
  Heart,
  ChevronLeft
} from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';

export const Footer: React.FC = () => {
  const { setCurrentPage, openTelegramBot, botUsername } = useConfig();

  return (
    <footer className="bg-[#1F1F1F] text-[#FAFAF8] pt-14 pb-20 md:pb-12 border-t border-black/20">
      {/* Top Value Assurance Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-white/10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="flex items-center gap-3.5 p-4 rounded-xl bg-white/5 border border-white/5">
            <div className="p-2.5 rounded-lg bg-[#C97C7C]/20 text-[#C97C7C]">
              <Truck size={22} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">ارسال سریع به سراسر ایران</h4>
              <p className="text-xs text-[#7A7A7A] mt-0.5">پست پیشتاز، تیپاکس و پیک فوری تهران</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-xl bg-white/5 border border-white/5">
            <div className="p-2.5 rounded-lg bg-[#C97C7C]/20 text-[#C97C7C]">
              <ShieldCheck size={22} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">تضمین کیفیت و اصالت پارچه</h4>
              <p className="text-xs text-[#7A7A7A] mt-0.5">بررسی دقیق تاروپود پیش از برش</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-xl bg-white/5 border border-white/5">
            <div className="p-2.5 rounded-lg bg-[#C97C7C]/20 text-[#C97C7C]">
              <Send size={20} className="rotate-45" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">مشاوره تلگرامی قبل از خرید</h4>
              <p className="text-xs text-[#7A7A7A] mt-0.5">ارسال ویدیو در نور طبیعی و محاسبه متراژ</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-xl bg-white/5 border border-white/5">
            <div className="p-2.5 rounded-lg bg-[#C97C7C]/20 text-[#C97C7C]">
              <Sparkles size={22} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">کالکشن‌های اختصاصی زنانه</h4>
              <p className="text-xs text-[#7A7A7A] mt-0.5">کرپ، ساتن، ژاکارد، لینن و حریر ترند</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Info */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          
          {/* Brand Col (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#C97C7C] text-white flex items-center justify-center font-bold text-lg">
                آ
              </div>
              <div>
                <span className="text-xl font-black text-white">پارچه آوین</span>
                <span className="block text-[10px] text-[#7A7A7A] tracking-wider font-light">AVIN WOMEN TEXTILES</span>
              </div>
            </div>
            
            <p className="text-xs sm:text-sm text-[#7A7A7A] leading-relaxed max-w-md">
              فروشگاه تخصصی «پارچه آوین» مرجع ارائه‌ی شیک‌ترین پارچه‌های مجلسی، مانتویی، شومیزی و کژوال زنانه. ما زیباترین بافت‌ها را از برترین کارخانه‌های نساجی گلچین می‌کنیم تا شما خاص‌ترین لباس‌ها را بدوزید.
            </p>

            {/* Telegram Bot Direct CTA Box */}
            <div className="pt-2">
              <button
                id="footer-telegram-cta"
                onClick={() => openTelegramBot()}
                className="inline-flex items-center gap-2.5 px-4 py-2.5 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-xs sm:text-sm font-semibold rounded-xl shadow-sm transition-all cursor-pointer"
              >
                <Send size={16} className="rotate-45" />
                <span>ثبت سفارش در ربات تلگرام (@{botUsername})</span>
              </button>
            </div>
          </div>

          {/* Quick links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold text-white border-r-2 border-[#C97C7C] pr-2.5">
              دسترسی سریع
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#7A7A7A]">
              <li>
                <button 
                  onClick={() => setCurrentPage('home')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  صفحه اصلی
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('products')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  کالکشن پارچه‌ها
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('order-guide')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  راهنمای گام‌به‌گام سفارش
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('about')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  درباره پارچه آوین
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('contact')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  تماس و پشتیبانی
                </button>
              </li>
            </ul>
          </div>

          {/* Categories Links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold text-white border-r-2 border-[#C97C7C] pr-2.5">
              دسته‌بندی پارچه‌ها
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#7A7A7A]">
              <li>
                <button 
                  onClick={() => setCurrentPage('products')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  پارچه‌های کرپ و مازراتی
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('products')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  ساتن آمریکایی و سیلک
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('products')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  ژاکارد مزونی و مجلسی
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('products')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  لینن و کتان اسلپ
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentPage('products')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  حریر فلورانس و اورگانزا
                </button>
              </li>
            </ul>
          </div>

          {/* Contact & Hours Info (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold text-white border-r-2 border-[#C97C7C] pr-2.5">
              اطلاعات و پشتیبانی
            </h4>
            <div className="space-y-2.5 text-xs text-[#7A7A7A]">
              <div className="flex items-start gap-2">
                <Clock size={16} className="text-[#C97C7C] shrink-0 mt-0.5" />
                <span>ساعات پاسخگویی در تلگرام: همه‌روزه ۱۰ الی ۲۲</span>
              </div>
              <div className="flex items-start gap-2">
                <Send size={16} className="text-[#C97C7C] shrink-0 mt-0.5" />
                <span className="font-mono dir-ltr">@{botUsername}</span>
              </div>
              <div className="flex items-start gap-2">
                <Instagram size={16} className="text-[#C97C7C] shrink-0 mt-0.5" />
                <span className="font-mono dir-ltr">@avin_textiles</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin size={16} className="text-[#C97C7C] shrink-0 mt-0.5" />
                <span>تهران، بازار بزرگ، سرای پارچه‌فروشان (ارسال مستقیم پستی)</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Bottom copyright */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-[#7A7A7A] gap-4">
        <p>
          تمامی حقوق مادی و معنوی برای فروشگاه «پارچه آوین» محفوظ است. © {toPersianDigits(1403)}
        </p>
        <div className="flex items-center gap-4 text-[11px]">
          <span>بدون سبد خرید پیچیده؛ سفارش مستقیم در تلگرام</span>
          <span>•</span>
          <span>تضمین سلامت بافت</span>
        </div>
      </div>
    </footer>
  );
};

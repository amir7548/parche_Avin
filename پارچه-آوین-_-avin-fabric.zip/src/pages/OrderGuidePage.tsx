import React, { useState } from 'react';
import { useConfig } from '../context/ConfigContext';
import { ORDER_STEPS, FAQS } from '../data/faqs';
import { 
  Send, 
  Sparkles, 
  Ruler, 
  Truck, 
  Clock, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle2, 
  ShieldCheck,
  MessageSquare,
  PackageCheck,
  Zap
} from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';

export const OrderGuidePage: React.FC = () => {
  const { openTelegramBot, setIsCalculatorOpen, setCurrentPage, botUsername } = useConfig();
  const [openFaqId, setOpenFaqId] = useState<string | null>('faq-1');
  const [activeFaqTab, setActiveFaqTab] = useState<'همه' | 'سفارش' | 'ارسال' | 'پارچه' | 'مرجوعی'>('همه');

  const filteredFaqs = FAQS.filter(
    f => activeFaqTab === 'همه' || f.category === activeFaqTab
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16 text-right">
      
      {/* Hero Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#C97C7C]/10 text-[#C97C7C] text-xs font-bold rounded-full">
          <Sparkles size={14} />
          <span>ساده، شفاف و بدون دردسر</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-[#1F1F1F]">
          راهنمای ثبت سفارش در ربات تلگرام آوین
        </h1>
        <p className="text-xs sm:text-sm text-[#7A7A7A] leading-relaxed">
          برای خرید پارچه نیازی به ثبت‌نام‌های طولانی، رمز عبور یا وارد کردن آدرس‌های پیچیده در سایت ندارید. همه چیز در چند ثانیه در محیط امن تلگرام انجام می‌شود.
        </p>
      </div>

      {/* 4-Step Interactive Flow */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {ORDER_STEPS.map((step) => (
          <div 
            key={step.step}
            className="relative bg-white border border-[#E7E7E2] hover:border-[#C97C7C] rounded-2xl p-6 shadow-2xs transition-all space-y-3 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="w-9 h-9 rounded-xl bg-[#1F1F1F] text-white flex items-center justify-center font-bold text-sm">
                  {toPersianDigits(step.step)}
                </span>
                <span className="text-[11px] font-semibold text-[#C97C7C] bg-[#C97C7C]/10 px-2 py-0.5 rounded">
                  مرحله {toPersianDigits(step.step)}
                </span>
              </div>

              <h3 className="text-base font-bold text-[#1F1F1F]">
                {step.title}
              </h3>
              
              <p className="text-xs text-[#7A7A7A] leading-relaxed mt-2">
                {step.description}
              </p>
            </div>

            {step.tip && (
              <div className="pt-3 border-t border-[#E7E7E2] text-[11px] text-[#1F1F1F]/80 bg-[#FAFAF8] p-2.5 rounded-lg">
                💡 <span className="font-semibold">نکته:</span> {step.tip}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Why Telegram Ordering Callout Box */}
      <div className="bg-[#1F1F1F] text-white rounded-2xl p-8 sm:p-10 relative overflow-hidden shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8 space-y-4">
            <span className="text-xs font-bold text-[#C97C7C]">چرا سفارش از طریق تلگرام؟</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold">
              خرید پارچه، تجربه‌ای شخصی و مشاوره‌محور است
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs text-[#E7E7E2]">
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-[#C97C7C] shrink-0" />
                <span>دریافت ویدیو پارچه در نور طبیعی روز قبل از برش</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-[#C97C7C] shrink-0" />
                <span>مشاوره رایگان متراژ با کارشناس ارشد خیاطی</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-[#C97C7C] shrink-0" />
                <span>تطابق رنگ با تکه لباس یا روسری ارسالی شما</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-[#C97C7C] shrink-0" />
                <span>رهگیری لحظه‌ای مرسوله پستی در چت خصوصی</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col gap-3 justify-center">
            <button
              onClick={() => openTelegramBot()}
              className="w-full py-3.5 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-sm font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send size={16} className="rotate-45" />
              <span>ورود مستقیم به ربات (@{botUsername})</span>
            </button>
            
            <button
              onClick={() => setIsCalculatorOpen(true)}
              className="w-full py-3 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Ruler size={16} />
              <span>محاسبه متراژ مورد نیاز لباس</span>
            </button>
          </div>
        </div>
      </div>

      {/* Response Times & Shipping Rates */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-[#E7E7E2] rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center font-bold">
            <Clock size={20} />
          </div>
          <h3 className="text-base font-bold text-[#1F1F1F]">سرعت پاسخگویی</h3>
          <p className="text-xs text-[#7A7A7A] leading-relaxed">
            ربات تلگرام آوین به صورت ۲۴ ساعته فعال است و پیام‌های نیازمند مشاوره در ساعات کاری (۱۰ الی ۲۲) معمولاً در کمتر از ۱۵ دقیقه توسط پشتیبان پاسخ داده می‌شوند.
          </p>
        </div>

        <div className="bg-white border border-[#E7E7E2] rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center font-bold">
            <Truck size={20} />
          </div>
          <h3 className="text-base font-bold text-[#1F1F1F]">روش‌ها و زمان تحویل</h3>
          <p className="text-xs text-[#7A7A7A] leading-relaxed">
            تهران: پیک موتوری در همان روز کاری.
            سایر شهرها: پست پیشتاز (۳ تا ۴ روز کاری) یا تیپاکس (۱ تا ۲ روز کاری) به انتخاب مشتری.
          </p>
        </div>

        <div className="bg-white border border-[#E7E7E2] rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center font-bold">
            <ShieldCheck size={20} />
          </div>
          <h3 className="text-base font-bold text-[#1F1F1F]">بسته‌بندی بهداشتی و ضدآب</h3>
          <p className="text-xs text-[#7A7A7A] leading-relaxed">
            پارچه‌ها ابتدا در سلفون ضخیم محافظ پیچیده شده و سپس در پاکت پستی حباب‌دار دوجداره پلمپ می‌شوند تا با تمیزی کامل به دست شما برسند.
          </p>
        </div>
      </div>

      {/* Comprehensive FAQs Accordion */}
      <div className="bg-white border border-[#E7E7E2] rounded-2xl p-6 sm:p-10 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E7E7E2] pb-5">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#1F1F1F]">
              پرسش‌های متداول مشتریان
            </h2>
            <p className="text-xs text-[#7A7A7A] mt-1">
              پاسخ به سوالات پرتکرار پیرامون ثبت سفارش، پارچه‌ها، متراژ و ارسال
            </p>
          </div>

          {/* Filter FAQ categories */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {(['همه', 'سفارش', 'ارسال', 'پارچه', 'مرجوعی'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveFaqTab(tab)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  activeFaqTab === tab
                    ? 'bg-[#C97C7C] text-white'
                    : 'bg-[#FAFAF8] text-[#7A7A7A] hover:bg-[#EFEFEA]'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {filteredFaqs.map(faq => {
            const isOpen = openFaqId === faq.id;
            return (
              <div key={faq.id} className="border border-[#E7E7E2] rounded-xl overflow-hidden">
                <button
                  onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                  className="w-full flex items-center justify-between p-4 bg-[#FAFAF8] hover:bg-[#F4F4F0] text-xs sm:text-sm font-bold text-[#1F1F1F] text-right transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C97C7C]"></span>
                    <span>{faq.question}</span>
                  </span>
                  {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>
                {isOpen && (
                  <div className="p-4 sm:p-5 bg-white text-xs sm:text-sm text-[#7A7A7A] leading-relaxed border-t border-[#E7E7E2]">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="p-4 bg-[#FAFAF8] rounded-xl text-center text-xs text-[#7A7A7A] space-y-2">
          <span>سوال دیگری دارید که در لیست بالا نبود؟</span>
          <div>
            <button
              onClick={() => openTelegramBot()}
              className="text-[#C97C7C] font-bold hover:underline inline-flex items-center gap-1 cursor-pointer"
            >
              <Send size={13} className="rotate-45" />
              <span>ارسال مستقیم پیام در تلگرام آوین</span>
            </button>
          </div>
        </div>
      </div>

    </div>
  );
};

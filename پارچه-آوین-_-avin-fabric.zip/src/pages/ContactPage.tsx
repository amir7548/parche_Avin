import React, { useState } from 'react';
import { useConfig } from '../context/ConfigContext';
import { 
  Send, 
  Phone, 
  Instagram, 
  MapPin, 
  Clock, 
  Mail, 
  MessageSquare, 
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { openTelegramBot, botUsername, showToast } = useConfig();
  
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    fabricCode: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      showToast('لطفاً نام و شماره تماس خود را وارد نمایید');
      return;
    }
    setSubmitted(true);
    showToast('پیام شما با موفقیت ثبت شد. به زودی در تلگرام/واتساپ پاسخ داده خواهد شد.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-16 space-y-12 text-right">
      
      {/* Title */}
      <div className="text-center max-w-xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#C97C7C]/10 text-[#C97C7C] text-xs font-bold rounded-full">
          <MessageSquare size={14} />
          <span>پاسخگویی سریع و مشاوره</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-[#1F1F1F]">
          تماس با فروشگاه «پارچه آوین»
        </h1>
        <p className="text-xs sm:text-sm text-[#7A7A7A] leading-relaxed">
          برای مشاوره انتخاب پارچه، استعلام موجودی طاقه، استعلام قیمت عمده یا پیگیری مرسوله پستی در خدمت شما هستیم.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        
        {/* Contact Info Cards (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Main Telegram Quick Action Card */}
          <div className="p-6 bg-[#1F1F1F] text-white rounded-2xl space-y-4 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-xl bg-[#C97C7C] text-white flex items-center justify-center">
                <Send size={20} className="rotate-45" />
              </div>
              <span className="text-xs text-[#C97C7C] font-semibold">کانال اصلی ارتباط</span>
            </div>

            <div>
              <h3 className="text-lg font-bold">ربات تلگرام پارچه آوین</h3>
              <p className="text-xs text-white/70 mt-1 leading-relaxed">
                سریع‌ترین مسیر ثبت سفارش، استعلام موجودی و دریافت ویدیوهای طبیعی از پارچه
              </p>
              <div className="mt-2 text-xs font-mono text-[#C97C7C] dir-ltr">
                @{botUsername}
              </div>
            </div>

            <button
              id="contact-telegram-chat-btn"
              onClick={() => openTelegramBot()}
              className="w-full py-3 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send size={15} className="rotate-45" />
              <span>شروع چت در ربات تلگرام</span>
            </button>
          </div>

          {/* Details list */}
          <div className="bg-white border border-[#E7E7E2] rounded-2xl p-6 space-y-4 shadow-2xs">
            <div className="flex items-start gap-3 pb-3 border-b border-[#E7E7E2]">
              <Clock size={18} className="text-[#C97C7C] shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">ساعات پاسخگویی و ثبت سفارش:</span>
                <span className="text-xs text-[#7A7A7A] mt-0.5 block">شنبه تا جمعه از ساعت ۱۰:۰۰ الی ۲۲:۰۰</span>
              </div>
            </div>

            <div className="flex items-start gap-3 pb-3 border-b border-[#E7E7E2]">
              <Phone size={18} className="text-[#C97C7C] shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">تلفن پشتیبانی و مشاوره:</span>
                <span className="text-xs text-[#7A7A7A] font-mono dir-ltr mt-0.5 block">۰۲۱-۵۵۶۶۷۷۸۸ / ۰۹۱۲-۳۴۵۶۷۸۹</span>
              </div>
            </div>

            <div className="flex items-start gap-3 pb-3 border-b border-[#E7E7E2]">
              <Instagram size={18} className="text-[#C97C7C] shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">صفحه اینستاگرام آوین:</span>
                <span className="text-xs text-[#7A7A7A] font-mono dir-ltr mt-0.5 block">@avin_textiles</span>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <MapPin size={18} className="text-[#C97C7C] shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">دفتر مرکزی و انبار توزیع:</span>
                <span className="text-xs text-[#7A7A7A] mt-0.5 block leading-relaxed">
                  تهران، خیابان خیام، بازار بزرگ تهران، سرای پارچه‌فروشان، پلاک ۴۲ (ارسال پستی به تمام کشور)
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Message / Inquiry Form (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-[#E7E7E2] rounded-2xl p-6 sm:p-10 shadow-2xs">
          <div className="border-b border-[#E7E7E2] pb-4 mb-6">
            <h3 className="text-lg font-bold text-[#1F1F1F]">فرم پیام مستقیم یا درخواست استعلام</h3>
            <p className="text-xs text-[#7A7A7A] mt-1">
              در صورت تمایل مشخصات درخواست یا کد پارچه را بنویسید تا همکاران ما در تلگرام با شما تماس بگیرند.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 bg-[#F9EFEF] border border-[#C97C7C]/30 rounded-xl text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-[#C97C7C] text-white flex items-center justify-center mx-auto">
                <CheckCircle2 size={24} />
              </div>
              <h4 className="text-base font-bold text-[#1F1F1F]">پیام شما دریافت شد!</h4>
              <p className="text-xs text-[#7A7A7A] max-w-sm mx-auto">
                کارشناس پارچه آوین ظرف کمتر از ۲ ساعت از طریق تلگرام یا پیامک با شماره {formData.phone} ارتباط برقرار خواهد کرد.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="text-xs text-[#C97C7C] font-semibold underline cursor-pointer"
              >
                ارسال پیام جدید
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1F1F1F] mb-1.5">
                    نام و نام‌خانوادگی: <span className="text-[#C97C7C]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: سارا محمدی"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-[#FAFAF8] border border-[#E7E7E2] focus:border-[#C97C7C] focus:bg-white rounded-xl text-xs sm:text-sm focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1F1F1F] mb-1.5">
                    شماره تماس / تلگرام: <span className="text-[#C97C7C]">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 bg-[#FAFAF8] border border-[#E7E7E2] focus:border-[#C97C7C] focus:bg-white rounded-xl text-xs sm:text-sm focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1F1F] mb-1.5">
                  کد پارچه یا موضوع (اختیاری):
                </label>
                <input
                  type="text"
                  placeholder="مثال: AV-101 یا استعلام موجودی طاقه کرپ"
                  value={formData.fabricCode}
                  onChange={(e) => setFormData({ ...formData, fabricCode: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#FAFAF8] border border-[#E7E7E2] focus:border-[#C97C7C] focus:bg-white rounded-xl text-xs sm:text-sm focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1F1F] mb-1.5">
                  متن پیام یا سوال شما:
                </label>
                <textarea
                  rows={4}
                  placeholder="متراژ مورد نظر، رنگ یا هر سوالی درباره پارچه دارید بنویسید..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#FAFAF8] border border-[#E7E7E2] focus:border-[#C97C7C] focus:bg-white rounded-xl text-xs sm:text-sm focus:outline-none"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#1F1F1F] hover:bg-black text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors cursor-pointer"
              >
                ارسال پیام به تیم آوین
              </button>
            </form>
          )}

        </div>

      </div>

    </div>
  );
};

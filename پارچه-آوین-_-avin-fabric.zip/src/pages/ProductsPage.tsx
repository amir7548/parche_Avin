import React, { useState, useMemo } from 'react';
import { useConfig } from '../context/ConfigContext';
import { PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { ProductCard } from '../components/ProductCard';
import { CategoryId, FabricPattern } from '../types';
import { 
  Search, 
  Filter, 
  SlidersHorizontal, 
  X, 
  RotateCcw, 
  Check, 
  Sparkles, 
  Send,
  ArrowUpDown
} from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';

export const ProductsPage: React.FC = () => {
  const { 
    searchQuery, 
    setSearchQuery, 
    selectedCategoryFilter, 
    setSelectedCategoryFilter,
    openTelegramBot,
    botUsername
  } = useConfig();

  const [selectedPattern, setSelectedPattern] = useState<string>('all');
  const [selectedColor, setSelectedColor] = useState<string>('all');
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [sortOption, setSortOption] = useState<'newest' | 'price-asc' | 'price-desc'>('newest');
  const [mobileFilterOpen, setMobileFilterOpen] = useState<boolean>(false);

  // Collect all unique colors from products
  const availableColors = useMemo(() => {
    const map = new Map<string, string>();
    PRODUCTS.forEach(p => {
      p.colors.forEach(c => {
        if (!map.has(c.name)) {
          map.set(c.name, c.hex);
        }
      });
    });
    return Array.from(map.entries()).map(([name, hex]) => ({ name, hex }));
  }, []);

  // Filter products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(product => {
      // Category filter
      if (selectedCategoryFilter !== 'all' && product.category !== selectedCategoryFilter) {
        return false;
      }
      // Pattern filter
      if (selectedPattern !== 'all' && product.pattern !== selectedPattern) {
        return false;
      }
      // Color filter
      if (selectedColor !== 'all' && !product.colors.some(c => c.name === selectedColor)) {
        return false;
      }
      // Season filter
      if (selectedSeason !== 'all' && !product.specs.season.includes(selectedSeason)) {
        return false;
      }
      // Search query (matches name or product id code)
      if (searchQuery.trim()) {
        const query = searchQuery.trim().toLowerCase();
        const matchesName = product.name.toLowerCase().includes(query);
        const matchesId = product.id.toLowerCase().includes(query);
        const matchesCategory = product.categoryName.toLowerCase().includes(query);
        const matchesMaterial = product.specs.material.toLowerCase().includes(query);
        if (!matchesName && !matchesId && !matchesCategory && !matchesMaterial) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortOption === 'price-asc') return a.pricePerMeter - b.pricePerMeter;
      if (sortOption === 'price-desc') return b.pricePerMeter - a.pricePerMeter;
      return 0; // Default order in catalog
    });
  }, [selectedCategoryFilter, selectedPattern, selectedColor, selectedSeason, searchQuery, sortOption]);

  const handleResetFilters = () => {
    setSelectedCategoryFilter('all');
    setSelectedPattern('all');
    setSelectedColor('all');
    setSelectedSeason('all');
    setSearchQuery('');
    setSortOption('newest');
  };

  const hasActiveFilters = 
    selectedCategoryFilter !== 'all' || 
    selectedPattern !== 'all' || 
    selectedColor !== 'all' || 
    selectedSeason !== 'all' || 
    searchQuery !== '';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8 text-right">
      
      {/* Header & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E7E7E2] pb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1F1F1F]">
            کالکشن تخصصی پارچه‌های زنانه
          </h1>
          <p className="text-xs sm:text-sm text-[#7A7A7A] mt-1">
            مشاهده انواع پارچه، بررسی مشخصات و ثبت مستقیم سفارش در ربات تلگرام
          </p>
        </div>

        {/* Telegram Direct Order Hint */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => openTelegramBot()}
            className="px-4 py-2 bg-[#C97C7C]/15 hover:bg-[#C97C7C]/25 text-[#C97C7C] border border-[#C97C7C]/30 text-xs sm:text-sm font-semibold rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Send size={15} className="rotate-45" />
            <span>مشاوره و ثبت سفارش در ربات (@{botUsername})</span>
          </button>
        </div>
      </div>

      {/* Category Tabs (Desktop & Mobile Scroll) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          id="category-tab-all"
          onClick={() => setSelectedCategoryFilter('all')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all cursor-pointer ${
            selectedCategoryFilter === 'all'
              ? 'bg-[#1F1F1F] text-white shadow-xs'
              : 'bg-white border border-[#E7E7E2] text-[#1F1F1F] hover:border-[#C97C7C]'
          }`}
        >
          همه پارچه‌ها ({toPersianDigits(PRODUCTS.length)})
        </button>

        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategoryFilter === cat.id;
          return (
            <button
              key={cat.id}
              id={`category-tab-${cat.id}`}
              onClick={() => setSelectedCategoryFilter(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#C97C7C] text-white shadow-xs'
                  : 'bg-white border border-[#E7E7E2] text-[#1F1F1F] hover:border-[#C97C7C]'
              }`}
            >
              {cat.name}
            </button>
          );
        })}
      </div>

      {/* Filter and Search Bar Controls */}
      <div className="bg-white border border-[#E7E7E2] rounded-xl p-4 shadow-2xs space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <input
              id="products-search-input"
              type="text"
              placeholder="جستجو بر اساس نام، جنس یا کد محصول (مثلاً AV-101)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#C97C7C] focus:bg-white"
            />
            {searchQuery ? (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-3 text-[#7A7A7A] hover:text-[#1F1F1F]"
              >
                <X size={16} />
              </button>
            ) : (
              <Search size={16} className="absolute left-3 top-3 text-[#7A7A7A]" />
            )}
          </div>

          {/* Quick Filters (Pattern, Season, Sort) */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Pattern Filter */}
            <select
              value={selectedPattern}
              onChange={(e) => setSelectedPattern(e.target.value)}
              className="px-3 py-2 text-xs bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl text-[#1F1F1F] focus:outline-none focus:border-[#C97C7C] cursor-pointer"
            >
              <option value="all">همه طرح‌ها</option>
              <option value="ساده">ساده</option>
              <option value="طرح‌دار">طرح‌دار</option>
              <option value="ژاکارد و برجسته">ژاکارد و برجسته</option>
            </select>

            {/* Season Filter */}
            <select
              value={selectedSeason}
              onChange={(e) => setSelectedSeason(e.target.value)}
              className="px-3 py-2 text-xs bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl text-[#1F1F1F] focus:outline-none focus:border-[#C97C7C] cursor-pointer"
            >
              <option value="all">همه فصل‌ها</option>
              <option value="بهاره">بهاره</option>
              <option value="تابستانه">تابستانه</option>
              <option value="پاییزه">پاییزه</option>
              <option value="چهارفصل">چهارفصل</option>
            </select>

            {/* Sort Order */}
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as any)}
              className="px-3 py-2 text-xs bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl text-[#1F1F1F] focus:outline-none focus:border-[#C97C7C] cursor-pointer"
            >
              <option value="newest">جدیدترین‌ها</option>
              <option value="price-asc">ارزان‌ترین به گران‌ترین</option>
              <option value="price-desc">گران‌ترین به ارزان‌ترین</option>
            </select>

            {/* Reset Button */}
            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="flex items-center gap-1 px-3 py-2 text-xs text-[#C97C7C] hover:bg-[#C97C7C]/10 rounded-xl transition-colors cursor-pointer"
              >
                <RotateCcw size={14} />
                <span>حذف فیلترها</span>
              </button>
            )}
          </div>

        </div>

        {/* Color Palette Filter Row */}
        <div className="pt-3 border-t border-[#E7E7E2] flex items-center gap-2 flex-wrap">
          <span className="text-xs text-[#7A7A7A] ml-2">فیلتر رنگ:</span>
          <button
            onClick={() => setSelectedColor('all')}
            className={`px-2.5 py-1 rounded-lg text-xs transition-colors cursor-pointer ${
              selectedColor === 'all' 
                ? 'bg-[#1F1F1F] text-white font-medium' 
                : 'bg-[#FAFAF8] text-[#7A7A7A] border border-[#E7E7E2]'
            }`}
          >
            همه رنگ‌ها
          </button>
          
          {availableColors.slice(0, 10).map((c) => {
            const isSelected = selectedColor === c.name;
            return (
              <button
                key={c.name}
                onClick={() => setSelectedColor(isSelected ? 'all' : c.name)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-[#C97C7C] bg-[#C97C7C]/10 text-[#C97C7C] font-bold ring-1 ring-[#C97C7C]'
                    : 'border-[#E7E7E2] bg-white text-[#1F1F1F] hover:border-[#C97C7C]/50'
                }`}
              >
                <span 
                  className="w-3 h-3 rounded-full border border-black/15 shadow-2xs" 
                  style={{ backgroundColor: c.hex }} 
                />
                <span>{c.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Results Header / Count */}
      <div className="flex items-center justify-between text-xs text-[#7A7A7A]">
        <span>نمایش {toPersianDigits(filteredProducts.length)} قواره پارچه</span>
        <span>عرض تمامی پارچه‌ها ۱۵۰ سانتی‌متر است</span>
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-white border border-[#E7E7E2] rounded-2xl p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center mx-auto text-2xl font-bold">
            ؟
          </div>
          <h3 className="text-lg font-bold text-[#1F1F1F]">پارچه‌ای با مشخصات انتخابی شما پیدا نشد</h3>
          <p className="text-xs text-[#7A7A7A] max-w-sm mx-auto">
            می‌توانید فیلترها را حذف کنید یا مدل دلخواه خود را در ربات تلگرام برای ما ارسال کنید تا از انبار موجودی چک کنیم.
          </p>
          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 bg-[#1F1F1F] text-white text-xs font-semibold rounded-lg hover:bg-black transition-colors cursor-pointer"
            >
              حذف تمام فیلترها
            </button>
            <button
              onClick={() => openTelegramBot()}
              className="px-4 py-2 bg-[#C97C7C] text-white text-xs font-semibold rounded-lg hover:bg-[#b66a6a] transition-colors cursor-pointer"
            >
              استعلام در تلگرام
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

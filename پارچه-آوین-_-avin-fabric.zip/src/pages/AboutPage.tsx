import React from 'react';
import { useConfig } from '../context/ConfigContext';
import { Sparkles, Heart, ShieldCheck, Send, CheckCircle2, ChevronLeft } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { setCurrentPage, openTelegramBot, botUsername } = useConfig();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-16 space-y-12 text-right">
      
      {/* Title & Badge */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#C97C7C]/10 text-[#C97C7C] text-xs font-bold rounded-full">
          <Sparkles size={14} />
          <span>داستان آوین</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-[#1F1F1F]">
          درباره «پارچه آوین»
        </h1>
        <p className="text-base text-[#7A7A7A] leading-relaxed">
          تلفیق لطافت بافت‌های زنانه و اصالت هنر نساجی برای خلق استایلی برازنده و ماندگار
        </p>
      </div>

      {/* Hero Image */}
      <div className="relative rounded-2xl overflow-hidden aspect-21/9 bg-[#EFEFEA] border border-[#E7E7E2] shadow-sm">
        <img
          src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=1200&q=80"
          alt="کارگاه و پارچه‌های آوین"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Main Story Narrative */}
      <div className="bg-white border border-[#E7E7E2] rounded-2xl p-6 sm:p-10 space-y-6 leading-relaxed text-sm sm:text-base text-[#1F1F1F]/90">
        <h2 className="text-xl font-bold text-[#1F1F1F] border-r-4 border-[#C97C7C] pr-3">
          هنر انتخاب پارچه‌ای که با شما حرف می‌زند
        </h2>
        
        <p>
          «پارچه آوین» با یک هدف شفاف شکل گرفت: ارائه پارچه‌هایی که نه تنها در نگاه اول زیبا به نظر برسند، بلکه در گذر زمان، شستشو و دوخت خیاطی نیز اصالت و وقار خود را حفظ کنند. ما باور داریم لباسی که می‌پوشید از تار و پود پارچه‌اش آغاز می‌شود؛ بنابراین تک‌تک طاقه‌های موجود در آوین از میان هزاران نمونه‌ی وارداتی و بافته‌شده در بهترین کارخانه‌های نساجی کره، ترکیه و ایران گلچین شده‌اند.
        </p>

        <p>
          در سال‌های اخیر، تغییر سبک خرید اینترنتی باعث شد تا ما ساده‌ترین و مطمئن‌ترین روش را برای مشتریان عزیزمان انتخاب کنیم. ما فرآیند خرید را از قالب سبدهای خرید خشک و مبهم خارج کردیم و آن را در بستر گفتگوی صمیمانه در ربات تلگرام پیاده‌سازی نمودیم؛ تا هر خریدار بتواند دقیقاً مانند لمس پارچه در فروشگاه، ویدیو در نور طبیعی روز ببیند و با کارشناس خیاطی مشورت کند.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-[#E7E7E2]">
          <div className="p-4 bg-[#FAFAF8] rounded-xl border border-[#E7E7E2] space-y-1">
            <span className="text-2xl font-black text-[#C97C7C] block">۱۰۰٪</span>
            <span className="text-xs font-bold text-[#1F1F1F]">کنترل سلامت بافت</span>
            <p className="text-[11px] text-[#7A7A7A]">بررسی سانت‌به‌سانت طاقه قبل از برش</p>
          </div>

          <div className="p-4 bg-[#FAFAF8] rounded-xl border border-[#E7E7E2] space-y-1">
            <span className="text-2xl font-black text-[#C97C7C] block">+۵۰</span>
            <span className="text-xs font-bold text-[#1F1F1F]">کد رنگی و طرح ترند</span>
            <p className="text-[11px] text-[#7A7A7A]">پالت‌های هماهنگ با ژورنال‌های سال</p>
          </div>

          <div className="p-4 bg-[#FAFAF8] rounded-xl border border-[#E7E7E2] space-y-1">
            <span className="text-2xl font-black text-[#C97C7C] block">۲۴/۷</span>
            <span className="text-xs font-bold text-[#1F1F1F]">پشتیبانی در ربات تلگرام</span>
            <p className="text-[11px] text-[#7A7A7A]">استعلام سریع موجودی و ثبت سفارش</p>
          </div>
        </div>
      </div>

      {/* Values & Principles */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-[#1F1F1F]">اصول و ارزش‌های آوین</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-5 bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-[#C97C7C] font-bold text-sm">
              <CheckCircle2 size={18} />
              <span>صداقت کامل در اعلام مشخصات</span>
            </div>
            <p className="text-xs text-[#7A7A7A] leading-relaxed">
              اگر پارچه‌ای آبرفت دارد، بدن‌نماست یا نیاز به آستری دارد، به صراحت در شناسنامه پارچه درج می‌گردد تا هیچ ابهامی برای خیاط شما باقی نماند.
            </p>
          </div>

          <div className="p-5 bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-[#C97C7C] font-bold text-sm">
              <CheckCircle2 size={18} />
              <span>قیمت‌گذاری منصفانه دست اول</span>
            </div>
            <p className="text-xs text-[#7A7A7A] leading-relaxed">
              تامین مستقیم طاقه‌ها از واردکنندگان اصلی و کارخانجات نساجی بدون واسطه، امکان عرضه با مناسب‌ترین قیمت متری را برای شما فراهم کرده است.
            </p>
          </div>
        </div>
      </div>

      {/* Direct CTA */}
      <div className="bg-[#1F1F1F] text-white p-8 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-right">
          <h4 className="text-lg font-bold">آماده دوختن یک لباس بی‌نظیر هستید؟</h4>
          <p className="text-xs text-[#7A7A7A]">کالکشن جدید پارچه‌های آوین را ببینید و در تلگرام گفتگو را آغاز کنید.</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentPage('products')}
            className="px-5 py-2.5 bg-white text-[#1F1F1F] text-xs sm:text-sm font-semibold rounded-xl hover:bg-[#FAFAF8] transition-colors cursor-pointer"
          >
            مشاهده پارچه‌ها
          </button>
          <button
            onClick={() => openTelegramBot()}
            className="px-5 py-2.5 bg-[#C97C7C] text-white text-xs sm:text-sm font-semibold rounded-xl hover:bg-[#b66a6a] transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Send size={15} className="rotate-45" />
            <span>ربات تلگرام</span>
          </button>
        </div>
      </div>

    </div>
  );
};

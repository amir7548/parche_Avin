import React from 'react';
import { useConfig } from '../context/ConfigContext';
import { CATEGORIES } from '../data/categories';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { 
  ArrowLeft, 
  Send, 
  Sparkles, 
  Ruler, 
  ShieldCheck, 
  Truck, 
  HeartHandshake, 
  Instagram, 
  ChevronLeft,
  Scissors,
  CheckCircle2
} from 'lucide-react';
import { toPersianDigits } from '../utils/formatters';

export const HomePage: React.FC = () => {
  const { 
    setCurrentPage, 
    setSelectedCategoryFilter, 
    openTelegramBot, 
    setIsCalculatorOpen,
    botUsername 
  } = useConfig();

  // Filter 6 new items and 6 bestsellers
  const newProducts = PRODUCTS.filter(p => p.tags.includes('جدید')).slice(0, 6);
  const bestSellers = PRODUCTS.filter(p => p.tags.includes('پرفروش')).slice(0, 6);

  const handleCategoryClick = (catId: any) => {
    setSelectedCategoryFilter(catId);
    setCurrentPage('products');
  };

  return (
    <div className="space-y-16 sm:space-y-24 pb-16">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-8 sm:pt-14 pb-12 sm:pb-20 border-b border-[#E7E7E2] bg-radial from-[#FAFAF8] via-[#F4F4F0] to-[#EAEAE3]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
            
            {/* Hero Text */}
            <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-right">
              
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-[#C97C7C]/30 text-[#C97C7C] text-xs font-semibold shadow-2xs">
                <Sparkles size={14} />
                <span>کالکشن جدید پارچه‌های زنانه ۱۴۰۳</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-[#1F1F1F] tracking-tight leading-[1.2] sm:leading-[1.18]">
                پارچه‌های خاص برای{' '}
                <span className="text-[#C97C7C] underline decoration-[#C97C7C]/30 decoration-wavy decoration-2">
                  استایل برازنده زنانه
                </span>
              </h1>

              <p className="text-base sm:text-lg text-[#7A7A7A] leading-relaxed max-w-2xl font-light">
                مجموعه‌ای دست‌چین از مرغوب‌ترین پارچه‌های کرپ، ساتن سیلک، ژاکارد مجلسی و لینن طبیعی. بدون نیاز به ثبت‌نام یا سبد خرید پیچیده؛ مدل را بپسندید و در یک کلیک در ربات تلگرام سفارش دهید.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
                <button
                  id="hero-explore-btn"
                  onClick={() => setCurrentPage('products')}
                  className="px-6 py-3.5 bg-[#1F1F1F] hover:bg-black text-white text-sm sm:text-base font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>مشاهده کالکشن پارچه‌ها</span>
                  <ChevronLeft size={18} />
                </button>

                <button
                  id="hero-telegram-btn"
                  onClick={() => openTelegramBot()}
                  className="px-6 py-3.5 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-sm sm:text-base font-semibold rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send size={17} className="rotate-45" />
                  <span>ثبت سفارش در ربات تلگرام</span>
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 border-t border-[#E7E7E2] grid grid-cols-3 gap-4 text-xs text-[#7A7A7A]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#C97C7C] shrink-0" />
                  <span>ارسال ویدیو در نور روز</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#C97C7C] shrink-0" />
                  <span>برش دقیق متراژ دلخواه</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#C97C7C] shrink-0" />
                  <span>پاسخگویی سریع تلگرام</span>
                </div>
              </div>

            </div>

            {/* Hero Image Showcase (Artistic Grid) */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white aspect-4/5">
                  <img
                    src="https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1200&q=85"
                    alt="پارچه‌های لوکس آوین"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex flex-col justify-end p-6 text-white text-right">
                    <span className="text-xs text-[#C97C7C] font-semibold">بافت‌های اصیل و ترند</span>
                    <h3 className="text-xl font-bold mt-0.5">کرپ مازراتی و ساتن آمریکایی</h3>
                    <p className="text-xs text-white/80 mt-1">تضمین ایستایی و ریزش مناسب دوخت مزونی</p>
                  </div>
                </div>

                {/* Floating Badge */}
                <div className="absolute -bottom-5 -left-4 sm:-left-6 bg-white border border-[#E7E7E2] rounded-xl p-3.5 shadow-xl flex items-center gap-3 backdrop-blur-md">
                  <div className="w-10 h-10 rounded-lg bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center font-bold">
                    <Send size={18} className="rotate-45" />
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold text-[#1F1F1F]">سفارش آسان با شناسه پارچه</div>
                    <div className="text-[11px] text-[#7A7A7A] font-mono dir-ltr">@{botUsername}</div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* 2. CATEGORIES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4 text-right">
          <div>
            <span className="text-xs font-bold text-[#C97C7C] tracking-wider uppercase">دسته‌بندی‌ها</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1F1F1F] mt-1">
              محبوب‌ترین جنس‌های پارچه زنانه
            </h2>
          </div>
          <button
            onClick={() => {
              setSelectedCategoryFilter('all');
              setCurrentPage('products');
            }}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#C97C7C] hover:text-[#b66a6a] transition-colors self-start sm:self-auto cursor-pointer"
          >
            <span>مشاهده همه پارچه‌ها</span>
            <ChevronLeft size={16} />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              id={`cat-card-${cat.id}`}
              onClick={() => handleCategoryClick(cat.id)}
              className="group text-right relative rounded-xl overflow-hidden bg-white border border-[#E7E7E2] hover:border-[#C97C7C] transition-all hover:shadow-md cursor-pointer flex flex-col"
            >
              <div className="aspect-square w-full overflow-hidden bg-[#EFEFEA]">
                <img
                  src={cat.image}
                  alt={cat.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-3 bg-white">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xs sm:text-sm text-[#1F1F1F] group-hover:text-[#C97C7C] transition-colors">
                    {cat.name}
                  </h3>
                  <span className="text-[10px] text-[#7A7A7A]">
                    {toPersianDigits(cat.count)} مدل
                  </span>
                </div>
                <span className="text-[10px] text-[#7A7A7A] uppercase font-light mt-0.5 block truncate">
                  {cat.enName}
                </span>
              </div>
            </button>
          ))}
        </div>
      </section>


      {/* 3. NEW ARRIVALS (جدیدترین‌ها - 6 محصول) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4 text-right">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C97C7C]">
              <Sparkles size={14} />
              <span>کالکشن جدید</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1F1F1F] mt-1">
              جدیدترین پارچه‌های رسیده به آوین
            </h2>
          </div>
          <button
            onClick={() => setCurrentPage('products')}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#1F1F1F] hover:text-[#C97C7C] transition-colors self-start sm:self-auto cursor-pointer"
          >
            <span>دیدن تمام جدیدترین‌ها</span>
            <ChevronLeft size={16} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {newProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>


      {/* 4. FABRIC YARDAGE CALCULATOR BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#1F1F1F] text-white rounded-2xl p-6 sm:p-10 relative overflow-hidden shadow-xl">
          <div className="absolute top-0 right-0 w-72 h-72 bg-[#C97C7C]/20 rounded-full filter blur-3xl pointer-events-none"></div>
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center text-right">
            <div className="lg:col-span-8 space-y-3">
              <div className="inline-flex items-center gap-2 text-xs font-semibold px-3 py-1 rounded-full bg-[#C97C7C]/20 text-[#C97C7C] border border-[#C97C7C]/30">
                <Scissors size={14} />
                <span>ابزار رایگان ویژه مشتریان آوین</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold">
                نمی‌دانید برای لباستان چند متر پارچه لازم است؟
              </h3>
              <p className="text-xs sm:text-sm text-[#7A7A7A] leading-relaxed max-w-xl">
                با محاسبه‌گر هوشمند آوین، بر اساس مدل انتخابی (مانتو کتی، شومیز، شلوار، پیراهن ماکسی) و قد و سایز خود، متراژ دقیق پارچه عرض ۱۵۰ را به صورت آنی به دست آورید.
              </p>
            </div>

            <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3 justify-center">
              <button
                id="home-open-calculator-btn"
                onClick={() => setIsCalculatorOpen(true)}
                className="px-6 py-3.5 bg-[#C97C7C] hover:bg-[#b66a6a] text-white text-sm font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Ruler size={18} />
                <span>باز کردن محاسبه‌گر متراژ</span>
              </button>
              
              <button
                onClick={() => openTelegramBot()}
                className="px-6 py-3.5 bg-white/10 hover:bg-white/15 text-white text-sm font-medium rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send size={16} className="rotate-45" />
                <span>مشاوره تخصصی خیاطی در تلگرام</span>
              </button>
            </div>
          </div>
        </div>
      </section>


      {/* 5. BEST SELLERS (پرفروش‌ها - 6 محصول) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4 text-right">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C97C7C]">
              <Sparkles size={14} />
              <span>محبوب خیاطان و مشتریان</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1F1F1F] mt-1">
              پرفروش‌ترین پارچه‌های این فصل
            </h2>
          </div>
          <button
            onClick={() => setCurrentPage('products')}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#1F1F1F] hover:text-[#C97C7C] transition-colors self-start sm:self-auto cursor-pointer"
          >
            <span>دیدن تمام پارچه‌ها</span>
            <ChevronLeft size={16} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>


      {/* 6. WHY AVIN FABRICS (مزیت‌ها و ویژگی‌ها) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#F4F4F0] border border-[#E7E7E2] rounded-2xl p-8 sm:p-12 text-right">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold text-[#C97C7C]">تعهد ما به شما</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1F1F1F] mt-1">
              چرا خرید پارچه از آوین مطمئن است؟
            </h2>
            <p className="text-xs sm:text-sm text-[#7A7A7A] mt-2">
              ما دغدغه‌های خرید اینترنتی پارچه (تطابق رنگ، کیفیت زیردست و متراژ) را کاملاً رفع کرده‌ایم.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl border border-[#E7E7E2] shadow-2xs space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center">
                <Truck size={24} />
              </div>
              <h3 className="text-base font-bold text-[#1F1F1F]">ارسال سریع به کل ایران</h3>
              <p className="text-xs text-[#7A7A7A] leading-relaxed">
                ارسال امن و بسته‌بندی نفوذناپذیر با پست پیشتاز و تیپاکس به تمام شهرها و ارسال همان روز با پیک برای ساکنان تهران.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-[#E7E7E2] shadow-2xs space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center">
                <Send size={22} className="rotate-45" />
              </div>
              <h3 className="text-base font-bold text-[#1F1F1F]">مشاوره مستقیم و ارسال ویدیو</h3>
              <p className="text-xs text-[#7A7A7A] leading-relaxed">
                در ربات تلگرام، قبل از برش پارچه می‌توانید درخواست فیلم با نور طبیعی، بررسی ضخامت و تطابق با مدل لباس داشته باشید.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-[#E7E7E2] shadow-2xs space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#C97C7C]/15 text-[#C97C7C] flex items-center justify-center">
                <ShieldCheck size={24} />
              </div>
              <h3 className="text-base font-bold text-[#1F1F1F]">تضمین اصالت و سلامت بافت</h3>
              <p className="text-xs text-[#7A7A7A] leading-relaxed">
                تمامی قواره‌ها قبل از برش زیر نور متمرکز کنترل کیفی شده و در صورت هرگونه نقص بافت یا لک، با احترام تعویض می‌گردند.
              </p>
            </div>
          </div>
        </div>
      </section>


      {/* 7. INSTAGRAM / LOOKBOOK SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6 text-right">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#C97C7C]">
              <Instagram size={16} />
              <span>@avin_textiles</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#1F1F1F] mt-1">
              تن‌پوش‌ها و ایده دوخت در اینستاگرام
            </h2>
          </div>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs sm:text-sm font-semibold text-[#1F1F1F] hover:text-[#C97C7C] transition-colors"
          >
            مشاهده صفحه اینستاگرام
          </a>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          {[
            {
              img: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=600&q=80',
              caption: 'ایده دوخت کت مازراتی زنانه'
            },
            {
              img: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=600&q=80',
              caption: 'شومیز ساتن سیلک دراپه'
            },
            {
              img: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=600&q=80',
              caption: 'مانتو عبایی لینن بهاره'
            },
            {
              img: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=600&q=80',
              caption: 'پیراهن مجلسی ژاکارد ترک'
            }
          ].map((item, idx) => (
            <div key={idx} className="group relative aspect-4/5 rounded-xl overflow-hidden bg-[#EFEFEA]">
              <img
                src={item.img}
                alt={item.caption}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3 text-white text-right">
                <span className="text-xs font-medium">{item.caption}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};

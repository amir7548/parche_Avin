import React, { useState } from 'react';
import { useConfig } from '../context/ConfigContext';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { 
  Send, 
  ChevronRight, 
  Copy, 
  Check, 
  Sparkles, 
  Ruler, 
  ShieldCheck, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Heart,
  Share2,
  Info,
  CheckCircle2
} from 'lucide-react';
import { formatPrice, toPersianDigits } from '../utils/formatters';

export const ProductDetailPage: React.FC = () => {
  const { 
    selectedProduct, 
    setCurrentPage, 
    openTelegramBot, 
    getTelegramDeepLink, 
    toggleFavorite, 
    isFavorite,
    showToast,
    setIsCalculatorOpen,
    botUsername
  } = useConfig();

  // If no product selected, fallback to first product
  const product = selectedProduct || PRODUCTS[0];
  const [activeImageIdx, setActiveImageIdx] = useState<number>(0);
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0]?.name || '');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [openFaqId, setOpenFaqId] = useState<string | null>('faq-1');

  const favorite = isFavorite(product.id);
  const telegramDeepLink = getTelegramDeepLink(product.id);

  // Related products from same category
  const relatedProducts = PRODUCTS.filter(
    p => p.category === product.category && p.id !== product.id
  ).slice(0, 3);

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(product.id);
    setCopiedCode(true);
    showToast(`کد محصول (${product.id}) کپی شد`);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: `مشاهده پارچه ${product.name} در فروشگاه آوین`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      showToast('لینک صفحه کپی شد');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12 text-right">
      
      {/* Breadcrumb & Navigation */}
      <div className="flex items-center justify-between text-xs text-[#7A7A7A] border-b border-[#E7E7E2] pb-4">
        <div className="flex items-center gap-1.5 flex-wrap">
          <button 
            onClick={() => setCurrentPage('home')} 
            className="hover:text-[#1F1F1F] cursor-pointer"
          >
            خانه
          </button>
          <span>/</span>
          <button 
            onClick={() => setCurrentPage('products')} 
            className="hover:text-[#1F1F1F] cursor-pointer"
          >
            پارچه‌ها
          </button>
          <span>/</span>
          <span className="text-[#C97C7C] font-semibold">{product.categoryName}</span>
          <span>/</span>
          <span className="text-[#1F1F1F] font-medium truncate max-w-[200px]">{product.name}</span>
        </div>

        <button
          onClick={() => setCurrentPage('products')}
          className="inline-flex items-center gap-1 text-[#1F1F1F] hover:text-[#C97C7C] font-medium cursor-pointer"
        >
          <span>بازگشت به لیست پارچه‌ها</span>
          <ChevronRight size={16} />
        </button>
      </div>

      {/* Main Product Showcase Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        
        {/* Left Column: Image Gallery (5 cols in desktop) */}
        <div className="lg:col-span-6 space-y-4">
          
          {/* Main Large Image */}
          <div className="relative aspect-4/5 rounded-2xl overflow-hidden bg-[#EFEFEA] border border-[#E7E7E2] shadow-sm">
            <img
              src={product.images[activeImageIdx] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            
            {/* Top Badges */}
            <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
              {product.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="text-xs font-bold px-3 py-1 rounded-full bg-[#1F1F1F]/85 text-white backdrop-blur-md shadow-xs"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Favorite & Share Buttons */}
            <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
              <button
                id="product-detail-fav-btn"
                onClick={() => toggleFavorite(product.id)}
                aria-label="نشان کردن"
                className={`p-2.5 rounded-full transition-all backdrop-blur-md shadow-sm cursor-pointer ${
                  favorite 
                    ? 'bg-[#C97C7C] text-white' 
                    : 'bg-white/80 hover:bg-white text-[#1F1F1F]'
                }`}
              >
                <Heart size={18} className={favorite ? 'fill-white' : ''} />
              </button>
              
              <button
                onClick={handleShare}
                aria-label="اشتراک‌گذاری"
                className="p-2.5 rounded-full bg-white/80 hover:bg-white text-[#1F1F1F] transition-all backdrop-blur-md shadow-sm cursor-pointer"
              >
                <Share2 size={18} />
              </button>
            </div>
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-3">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`relative w-20 h-24 rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                    activeImageIdx === idx 
                      ? 'border-[#C97C7C] ring-2 ring-[#C97C7C]/20' 
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Quality Assurance Note */}
          <div className="bg-[#F9EFEF] border border-[#C97C7C]/30 rounded-xl p-4 flex items-start gap-3">
            <ShieldCheck size={22} className="text-[#C97C7C] shrink-0 mt-0.5" />
            <div className="text-xs text-[#1F1F1F] leading-relaxed">
              <strong>تضمین تطابق رنگ و فیلمبرداری اختصاصی:</strong>
              <p className="text-[#7A7A7A] mt-0.5">
                قبل از نهایی شدن سفارش در تلگرام، می‌توانید درخواست فیلمبرداری کوتاه زیر نور طبیعی برای تطبیق دقیق با رنگ پوست یا مدل خود داشته باشید.
              </p>
            </div>
          </div>
        </div>


        {/* Right Column: Details, Specs, Price, CTA (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Header Info */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-[#C97C7C] bg-[#C97C7C]/10 px-3 py-1 rounded-full">
                دسته‌بندی: {product.categoryName}
              </span>

              {/* Product Code Copy Chip */}
              <button
                id="copy-product-code-btn"
                onClick={handleCopyCode}
                title="برای کپی کد کلیک کنید"
                className="flex items-center gap-1.5 px-3 py-1 bg-[#FAFAF8] hover:bg-[#EFEFEA] border border-[#E7E7E2] rounded-lg text-xs font-mono text-[#1F1F1F] transition-colors cursor-pointer"
              >
                <span>کد: {product.id}</span>
                {copiedCode ? <Check size={14} className="text-green-600" /> : <Copy size={14} className="text-[#7A7A7A]" />}
              </button>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-[#1F1F1F] leading-tight">
              {product.name}
            </h1>
            
            <p className="text-xs sm:text-sm text-[#7A7A7A] leading-relaxed pt-1">
              {product.description}
            </p>
          </div>

          {/* Price Box */}
          <div className="p-4 bg-[#FAFAF8] rounded-xl border border-[#E7E7E2] flex items-center justify-between">
            <div>
              <span className="text-xs text-[#7A7A7A] block">قیمت پارچه:</span>
              <span className="text-xs text-[#7A7A7A]">(عرض ۱۵۰ سانتی‌متر)</span>
            </div>
            <div className="text-left">
              {product.oldPricePerMeter && (
                <span className="text-xs text-[#7A7A7A] line-through block">
                  {formatPrice(product.oldPricePerMeter)}
                </span>
              )}
              <span className="text-xl sm:text-2xl font-extrabold text-[#1F1F1F]">
                {formatPrice(product.pricePerMeter)}
              </span>
              <span className="text-xs text-[#7A7A7A] block">به ازای هر متر</span>
            </div>
          </div>

          {/* Color Selection */}
          {product.colors && product.colors.length > 0 && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#1F1F1F] flex items-center justify-between">
                <span>رنگ‌بندی موجود:</span>
                <span className="text-[#C97C7C] font-normal">{selectedColor}</span>
              </label>
              <div className="flex items-center gap-2 flex-wrap">
                {product.colors.map((c, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedColor(c.name)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs transition-all cursor-pointer ${
                      selectedColor === c.name
                        ? 'border-[#C97C7C] bg-[#C97C7C]/10 text-[#C97C7C] font-bold ring-1 ring-[#C97C7C]'
                        : 'border-[#E7E7E2] bg-white text-[#1F1F1F] hover:border-[#C97C7C]/50'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-black/15 shadow-2xs"
                      style={{ backgroundColor: c.hex }}
                    />
                    <span>{c.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Primary CTA Box: "ثبت سفارش در ربات تلگرام" */}
          <div className="p-5 bg-[#1F1F1F] text-white rounded-2xl space-y-3 shadow-lg">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#C97C7C] font-semibold flex items-center gap-1">
                <Sparkles size={14} />
                ثبت سفارش بدون نیاز به حساب کاربری
              </span>
              <span className="text-[11px] text-white/60 font-mono">@{botUsername}</span>
            </div>

            {/* Deep link button */}
            <a
              id="product-detail-telegram-cta"
              href={telegramDeepLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => showToast(`در حال اتصال به ربات تلگرام برای پارچه کد ${product.id}...`)}
              className="w-full py-3.5 px-4 bg-[#C97C7C] hover:bg-[#b66a6a] active:bg-[#a35c5c] text-white text-sm sm:text-base font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2.5 cursor-pointer no-underline text-center"
            >
              <Send size={18} className="rotate-45" />
              <span>ثبت سفارش در ربات تلگرام</span>
            </a>

            <p className="text-[11px] text-white/70 text-center leading-relaxed">
              با کلیک روی دکمه بالا، مشخصات پارچه <strong>{product.name} (کد {product.id})</strong> به ربات منتقل می‌شود.
            </p>
          </div>

          {/* Quick 3-Step Ordering Box */}
          <div className="border border-[#E7E7E2] rounded-xl p-4 bg-white space-y-3">
            <h4 className="text-xs font-bold text-[#1F1F1F] flex items-center gap-2">
              <Info size={16} className="text-[#C97C7C]" />
              <span>چطور این پارچه را سفارش بدهم؟ (۳ مرحله ساده)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs text-[#7A7A7A]">
              <div className="p-2.5 rounded-lg bg-[#FAFAF8] border border-[#E7E7E2]">
                <div className="font-bold text-[#1F1F1F] mb-1">۱. کلیک روی دکمه</div>
                <p className="text-[11px]">روی «ثبت سفارش در ربات تلگرام» بزنید.</p>
              </div>
              <div className="p-2.5 rounded-lg bg-[#FAFAF8] border border-[#E7E7E2]">
                <div className="font-bold text-[#1F1F1F] mb-1">۲. اعلام متراژ</div>
                <p className="text-[11px]">رنگ و متراژ را در ربات تلگرام بفرستید.</p>
              </div>
              <div className="p-2.5 rounded-lg bg-[#FAFAF8] border border-[#E7E7E2]">
                <div className="font-bold text-[#1F1F1F] mb-1">۳. ارسال سریع</div>
                <p className="text-[11px]">تایید و ارسال پستی با کد رهگیری.</p>
              </div>
            </div>
          </div>

          {/* Calculator Trigger Banner */}
          <div className="flex items-center justify-between p-3.5 bg-[#FAFAF8] border border-[#E7E7E2] rounded-xl">
            <div className="flex items-center gap-2 text-xs">
              <Ruler size={17} className="text-[#C97C7C]" />
              <span className="font-semibold text-[#1F1F1F]">نیاز به محاسبه متراژ دقیق دارید؟</span>
            </div>
            <button
              onClick={() => setIsCalculatorOpen(true)}
              className="text-xs font-bold text-[#C97C7C] hover:underline cursor-pointer"
            >
              باز کردن محاسبه‌گر
            </button>
          </div>

        </div>

      </div>


      {/* Detailed Specifications Table */}
      <section className="bg-white border border-[#E7E7E2] rounded-2xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-[#E7E7E2] pb-4">
          <h2 className="text-xl font-bold text-[#1F1F1F]">
            مشخصات کامل و فنی پارچه {product.name}
          </h2>
          <p className="text-xs text-[#7A7A7A] mt-0.5">
            تمام اطلاعات لازم برای برشکار و خیاط شما
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { label: 'جنس و الیاف پارچه', value: product.specs.material },
            { label: 'عرض مفید پارچه', value: product.specs.width },
            { label: 'مناسب برای دوخت', value: product.specs.suitableFor.join('، ') },
            { label: 'فصل‌های پیشنهادی', value: product.specs.season.join('، ') },
            { label: 'میزان کشسانی', value: product.specs.stretch },
            { label: 'ریزش و ایستایی', value: product.specs.drape },
            { label: 'میزان شفافیت و آستر', value: product.specs.sheerness },
            { label: 'مقاومت در برابر چروک', value: product.specs.wrinkleResistance },
            { label: 'وضعیت آبرفت', value: product.specs.shrinkage },
            { label: 'نحوه شستشو و اتوکشی', value: product.specs.careInstructions }
          ].map((item, idx) => (
            <div key={idx} className="flex flex-col sm:flex-row sm:items-baseline justify-between p-3 rounded-lg bg-[#FAFAF8] border border-[#E7E7E2]/70 text-xs">
              <span className="font-bold text-[#7A7A7A] sm:w-1/3 mb-1 sm:mb-0">{item.label}:</span>
              <span className="font-medium text-[#1F1F1F] sm:w-2/3 leading-relaxed">{item.value}</span>
            </div>
          ))}
        </div>
      </section>


      {/* Recommended Garments & Suggested Yardage */}
      {product.recommendedGarments && product.recommendedGarments.length > 0 && (
        <section className="bg-[#FAFAF8] border border-[#E7E7E2] rounded-2xl p-6 sm:p-8 space-y-4">
          <h3 className="text-lg font-bold text-[#1F1F1F] flex items-center gap-2">
            <Ruler size={18} className="text-[#C97C7C]" />
            <span>متراژ پیشنهادی برای دوخت با این پارچه</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {product.recommendedGarments.map((g, idx) => (
              <div key={idx} className="p-4 bg-white rounded-xl border border-[#E7E7E2] text-center">
                <span className="text-xs text-[#7A7A7A] block mb-1">{g.name}</span>
                <span className="text-base font-extrabold text-[#C97C7C]">{g.suggestedMeters}</span>
                <span className="text-[10px] text-[#7A7A7A] block mt-1">عرض ۱۵۰ سانتی‌متر</span>
              </div>
            ))}
          </div>
        </section>
      )}


      {/* FAQ for this Product */}
      <section className="bg-white border border-[#E7E7E2] rounded-2xl p-6 sm:p-8 space-y-4">
        <h3 className="text-lg font-bold text-[#1F1F1F] flex items-center gap-2">
          <HelpCircle size={18} className="text-[#C97C7C]" />
          <span>سوالات متداول درباره خرید پارچه {product.name}</span>
        </h3>
        
        <div className="space-y-3 pt-2">
          {[
            {
              id: 'faq-1',
              q: 'حداقل متراژ قابل سفارش برای این پارچه چقدر است؟',
              a: 'حداقل متراژ سفارش ۱ متر است و پس از آن با ضریب ۱۰ سانتی‌متر (مثلاً ۱.۳۰ یا ۲.۴۰ متر) قابل برش و سفارش در تلگرام است.'
            },
            {
              id: 'faq-2',
              q: 'آیا این پارچه نیاز به اتوکشی مداوم دارد یا چروک نمی‌شود؟',
              a: product.specs.wrinkleResistance + ' است. برای دوام بیشتر الیاف، توصیه می‌کنیم با حرارت ملایم و بخار اتو شود.'
            },
            {
              id: 'faq-3',
              q: 'اگر پارچه ایراد یا لک داشته باشد چه کار کنم؟',
              a: 'کلیه پارچه‌های آوین با ضمانت سلامت بافت ارسال می‌شوند. در صورت هرگونه نقص پیش از برش خیاطی شما، پارچه با هزینه آوین مرجوع یا تعویض می‌شود.'
            }
          ].map(faq => {
            const isOpen = openFaqId === faq.id;
            return (
              <div key={faq.id} className="border border-[#E7E7E2] rounded-xl overflow-hidden">
                <button
                  onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                  className="w-full flex items-center justify-between p-4 bg-[#FAFAF8] hover:bg-[#F4F4F0] text-xs sm:text-sm font-bold text-[#1F1F1F] text-right transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>
                {isOpen && (
                  <div className="p-4 bg-white text-xs text-[#7A7A7A] leading-relaxed border-t border-[#E7E7E2]">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>


      {/* Related Fabrics */}
      {relatedProducts.length > 0 && (
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-[#1F1F1F]">
              سایر پارچه‌های هم‌خانواده ({product.categoryName})
            </h3>
            <button
              onClick={() => setCurrentPage('products')}
              className="text-xs font-semibold text-[#C97C7C] hover:underline cursor-pointer"
            >
              مشاهده همه
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {relatedProducts.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

    </div>
  );
};

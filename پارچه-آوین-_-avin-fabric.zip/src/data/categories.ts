import { FabricCategory } from '../types';

export const CATEGORIES: FabricCategory[] = [
  {
    id: 'crepe',
    name: 'کرپ',
    enName: 'Crepe',
    description: 'ریزش عالی، چروک‌ناپذیر و مناسب مانتو و کت زنانه',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80',
    count: 14
  },
  {
    id: 'satin',
    name: 'ساتن',
    enName: 'Satin & Silk',
    description: 'درخشش ابریشمی، لطیف و بی‌نظیر برای شومیز و لباس شب',
    image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=800&q=80',
    count: 10
  },
  {
    id: 'linen',
    name: 'لینن و کتان',
    enName: 'Linen & Cotton',
    description: 'تنفس‌پذیر، خنک و ترند روز برای استایل‌های بهاره و تابستانه',
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=800&q=80',
    count: 12
  },
  {
    id: 'jacquard',
    name: 'ژاکارد',
    enName: 'Jacquard',
    description: 'بافت‌های فاخر با گل‌های برجسته، لمه و سیم‌بافت برای مجلسی و کت',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80',
    count: 9
  },
  {
    id: 'silk',
    name: 'حریر و اورگانزا',
    enName: 'Chiffon & Organza',
    description: 'سبک، رویایی و شناور با ظرافت بی‌همتا برای پیراهن و شال',
    image: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=800&q=80',
    count: 8
  },
  {
    id: 'velvet',
    name: 'مخمل و کرک‌دار',
    enName: 'Velvet',
    description: 'پرزهای ابریشمی، باوقار و گرمابخش برای لباس شب و کت پاییزی',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80',
    count: 6
  }
];

import { FabricProduct } from '../types';

export const PRODUCTS: FabricProduct[] = [
  {
    id: 'AV-101',
    name: 'کرپ مازراتی اعلا درجه یک',
    category: 'crepe',
    categoryName: 'کرپ',
    pattern: 'ساده',
    pricePerMeter: 340000,
    oldPricePerMeter: 390000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'رز پودری', hex: '#C97C7C' },
      { name: 'مشکی کلاغی', hex: '#1F1F1F' },
      { name: 'کرم نود', hex: '#E6D7C3' },
      { name: 'سبز کله‌غازی', hex: '#1C4940' },
      { name: 'طوسی فیلی', hex: '#9E9E9E' }
    ],
    tags: ['جدید', 'پرفروش'],
    inStock: true,
    specs: {
      material: 'پلی‌استر ویسکوز اعلا با الیاف متراکم',
      width: '۱۵۰ سانتی‌متر مفید',
      suitableFor: ['مانتو کتی', 'کت و شلوار زنانه', 'شومیز رسمی', 'سارافون'],
      season: ['چهارفصل', 'بهاره', 'پاییزه'],
      stretch: 'کشسانی کم (عرضی)',
      drape: 'ایستایی متوسط و خوش‌فرم',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'شستشو با آب ۳۰ درجه و مایع ملایم، اتوکشی با دمای متوسط و از پشت پارچه'
    },
    description: 'کرپ مازراتی یکی از پرکاربردترین و شیک‌ترین پارچه‌ها برای استایل بانوان است. با بافت دانه‌ریز، لمس نرم و ایستایی فوق‌العاده‌اش، تن‌خور بسیار تمیز و لوکسی به کت و شلوارهای مجلسی و مانتوهای اداری می‌بخشد.',
    recommendedGarments: [
      { name: 'مانتو کتی شیک', suggestedMeters: '۱.۷۰ تا ۲ متر' },
      { name: 'کت و شلوار ست', suggestedMeters: '۳ تا ۳.۳۰ متر' },
      { name: 'شلوار راسته زنانه', suggestedMeters: '۱.۱۰ تا ۱.۳۰ متر' }
    ]
  },
  {
    id: 'AV-102',
    name: 'ساتن آمریکایی سیلک براق',
    category: 'satin',
    categoryName: 'ساتن',
    pattern: 'ساده',
    pricePerMeter: 480000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'شامپاینی', hex: '#EED9C4' },
      { name: 'یاسی ملایم', hex: '#D8C3E5' },
      { name: 'زرشکی متالیک', hex: '#800020' },
      { name: 'طلایی خاموش', hex: '#D4AF37' }
    ],
    tags: ['جدید', 'پیشنهاد ویژه'],
    inStock: true,
    specs: {
      material: 'ساتن سیلک کره‌ای با نخ دوبل',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['لباس مجلسی', 'پیراهن شب', 'شومیز ترند', 'دامن کلوش'],
      season: ['چهارفصل', 'بهاره'],
      stretch: 'بدون کش',
      drape: 'ریزش‌دار و لخت و سنگین',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'خشکشویی یا شستشوی دستی با آب سرد و مایع سیلک، اتو در حالت بخار کم'
    },
    description: 'ساتن آمریکایی درجه یک با ضخامت متناسب، ایستایی سنگین و براقیت لطیف، انتخابی ایده‌آل برای دوخت پیراهن‌های مجلسی، اورال و شومیزهای گره‌ای است.',
    recommendedGarments: [
      { name: 'پیراهن مجلسی بلند', suggestedMeters: '۲.۵ تا ۳ متر' },
      { name: 'شومیز یقه پاپیونی', suggestedMeters: '۱.۵۰ متر' },
      { name: 'دامن نیم کلوش', suggestedMeters: '۱.۸۰ متر' }
    ]
  },
  {
    id: 'AV-103',
    name: 'ژاکارد ترک کتی طرح ترنج زرشکی و طلا',
    category: 'jacquard',
    categoryName: 'ژاکارد',
    pattern: 'ژاکارد و برجسته',
    pricePerMeter: 690000,
    oldPricePerMeter: 750000,
    widthCm: 145,
    images: [
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'طلایی و زرشکی', hex: '#B33939' },
      { name: 'سرمه‌ای و نقره‌ای', hex: '#192A56' },
      { name: 'مشکی با سیم برنز', hex: '#2C3A47' }
    ],
    tags: ['پرفروش', 'پیشنهاد ویژه'],
    inStock: true,
    specs: {
      material: 'تار و پود ژاکارد با نخ سیم ترک و پنبه',
      width: '۱۴۵ سانتی‌متر',
      suitableFor: ['مانتو مجلسی', 'کت ترند بهاره', 'وست و ژیله', 'دامن فون'],
      season: ['بهاره', 'پاییزه'],
      stretch: 'بدون کش',
      drape: 'آهاردار و شق‌ورق',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'ترجیحاً خشکشویی شود، اتوکشی فقط از پشت پارچه با لایه محافظ'
    },
    description: 'ژاکارد مزونی اعلا با بافت سیم‌باف و طرح‌های اصیل ترنج. آهار طبیعی این پارچه فرم بی‌نقصی به کت‌های ساختاریافته و مانتوهای تشریفاتی می‌دهد.',
    recommendedGarments: [
      { name: 'کت مزونی کوتاه', suggestedMeters: '۱.۵۰ متر' },
      { name: 'مانتو مجلسی بلند', suggestedMeters: '۲ تا ۲.۳۰ متر' },
      { name: 'وست و سارافون', suggestedMeters: '۱.۳۰ متر' }
    ]
  },
  {
    id: 'AV-104',
    name: 'لینن اسلپ بهاره کتان ارگانیک',
    category: 'linen',
    categoryName: 'لینن و کتان',
    pattern: 'ساده',
    pricePerMeter: 310000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'سبز ساج', hex: '#9CAF88' },
      { name: 'خاکی شنی', hex: '#D2B48C' },
      { name: 'سفید شیری', hex: '#FDFBF7' },
      { name: 'آجری روستیک', hex: '#C05A46' },
      { name: 'سرمه‌ای اقیانوسی', hex: '#273c75' }
    ],
    tags: ['جدید', 'پرفروش'],
    inStock: true,
    specs: {
      material: '۱۰۰٪ الیاف طبیعی کتان لینن بدون پلاستیک',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['مانتو تابستانه', 'شومیز کژوال', 'شلوار بگ', 'پیراهن خنک'],
      season: ['بهاره', 'تابستانه'],
      stretch: 'بدون کش',
      drape: 'ایستایی متوسط و سبک',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'چروک‌پذیری طبیعی کتان (به آسانی با اتوی بخار باز می‌شود)',
      shrinkage: 'حدود ۱ الی ۲ درصد آبرفت',
      careInstructions: 'قبل از برش حتماً آبکشی شود، شستشو با دور ملایم و آب ولرم'
    },
    description: 'لینن خالص اسلپ‌دار با بافت ارگانیک و تنفس‌پذیری بی‌نظیر. گزینه‌ای خنک، دوستدار پوست و ترند برای استایل‌های روزمره مینیمال زنانه.',
    recommendedGarments: [
      { name: 'شومیز راحت اورسایز', suggestedMeters: '۱.۴۰ متر' },
      { name: 'مانتو تابستانه عبایی', suggestedMeters: '۲.۲۰ متر' },
      { name: 'شلوار بگ راحتی', suggestedMeters: '۱.۲۰ متر' }
    ]
  },
  {
    id: 'AV-105',
    name: 'حریر کرپ فلورانس ابریشمی',
    category: 'silk',
    categoryName: 'حریر و اورگانزا',
    pattern: 'ساده',
    pricePerMeter: 275000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'هلویی ملیح', hex: '#FFDAB9' },
      { name: 'آبی پودری', hex: '#B0E0E6' },
      { name: 'مشکی ابریشم', hex: '#1B1B1B' },
      { name: 'نباتی صدفی', hex: '#FFF8DC' }
    ],
    tags: ['جدید'],
    inStock: true,
    specs: {
      material: 'تار و پود حریر فلورانس کرپ با زیردست مخملی',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['شومیز زنانه', 'پیراهن لایه‌ای', 'دامن پلیسه', 'شال و روسری'],
      season: ['بهاره', 'تابستانه', 'چهارفصل'],
      stretch: 'بدون کش',
      drape: 'بسیار سبک، لطیف و ریزش‌دار',
      sheerness: 'نیمه شفاف (نیاز به آستر برای دامن/لباس)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'شستشوی دستی با شوینده بدون آنزیم، اتوکشی با درجه کم'
    },
    description: 'حریر فلورانس با بافتی مات و لخت، برخلاف حریرهای معمولی لیز نمی‌خورد و چروک نمی‌شود. نمایی لطیف و شاعرانه به شومیزها و پیراهن‌های ماکسی می‌دهد.',
    recommendedGarments: [
      { name: 'شومیز آستین پفی', suggestedMeters: '۱.۶۰ متر' },
      { name: 'پیراهن چندطبقه ساحلی', suggestedMeters: '۳.۵۰ متر' },
      { name: 'شال مجلسی شیک', suggestedMeters: '۲ متر' }
    ]
  },
  {
    id: 'AV-106',
    name: 'مخمل سوئیت گرم بالا پاییزه',
    category: 'velvet',
    categoryName: 'مخمل و کرک‌دار',
    pattern: 'ساده',
    pricePerMeter: 420000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'شکلاتی تیره', hex: '#4B3621' },
      { name: 'سبز یشمی', hex: '#004225' },
      { name: 'کالباسی دودی', hex: '#B38B88' },
      { name: 'مشکی مات', hex: '#212121' }
    ],
    tags: ['پرفروش'],
    inStock: true,
    specs: {
      material: 'پلی‌استر میکروفایبر پرتراکم (سوئیت مخملی)',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['پالتو سبک', 'مانتو پاییزه', 'کت چرم‌نما', 'دامن راسته'],
      season: ['پاییزه', 'زمستانه'],
      stretch: 'کشسانی کم (عرضی)',
      drape: 'ایستایی متوسط و خوش‌فرم',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'شستشو در جهت خواب پرز پارچه، اتوکشی از پشت با پارچه محافظ'
    },
    description: 'سوئیت گرم بالا با لطافت مخملین، دوام استثنایی و گرمایی ملایم، برای دوخت کت‌های پاییزه، پالتوهای شیک و دامن‌های رسمی ایده‌آل است.',
    recommendedGarments: [
      { name: 'کت پاییزه آسترکشی', suggestedMeters: '۱.۸۰ متر' },
      { name: 'پالتو کلاسیک زنانه', suggestedMeters: '۲.۵۰ تا ۲.۸۰ متر' },
      { name: 'دامن میدی رسمی', suggestedMeters: '۱ متر' }
    ]
  },
  {
    id: 'AV-107',
    name: 'کرپ اسکاچی گرم بالا مات',
    category: 'crepe',
    categoryName: 'کرپ',
    pattern: 'ساده',
    pricePerMeter: 290000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1520006403909-838d6b92c22e?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'طوسی تیره', hex: '#4A4A4A' },
      { name: 'بادمجانی', hex: '#4A154B' },
      { name: 'کرم نسکافه‌ای', hex: '#C4A482' },
      { name: 'سورمه‌ای تیره', hex: '#1E293B' }
    ],
    tags: ['جدید', 'پرفروش'],
    inStock: true,
    specs: {
      material: 'پلی‌استر کرپ کریستال با تنفس بالا',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['مانتو دانشجویی و اداری', 'شلوار دمپا', 'سارافون'],
      season: ['چهارفصل'],
      stretch: 'کشسانی کم (عرضی)',
      drape: 'ریزش‌دار و لخت',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'شستشوی آسان با ماشین لباسشویی بدون نیاز به اتوکشی مداوم'
    },
    description: 'کرپ اسکاچی به دوام بالا و عدم چروک‌پذیری شهرت دارد. برای بانوانی که به دنبال لباس‌های روزمره با نگهداری آسان و تن‌خور مرتب هستند.',
    recommendedGarments: [
      { name: 'مانتو روزمره بلند', suggestedMeters: '۲.۰۰ متر' },
      { name: 'شلوار کلاسیک', suggestedMeters: '۱.۱۵ متر' }
    ]
  },
  {
    id: 'AV-108',
    name: 'ژاکارد پفکی لمه‌دار نقره‌ای طرح پروانه',
    category: 'jacquard',
    categoryName: 'ژاکارد',
    pattern: 'ژاکارد و برجسته',
    pricePerMeter: 740000,
    oldPricePerMeter: 820000,
    widthCm: 145,
    images: [
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'نقره‌ای یاسی', hex: '#C5B4E3' },
      { name: 'شامپاین طلایی', hex: '#DFC195' },
      { name: 'سفید برفی سیم‌دار', hex: '#F5F5F5' }
    ],
    tags: ['جدید', 'پیشنهاد ویژه'],
    inStock: true,
    specs: {
      material: 'بافت ژاکارد حجمی با سیم لمه ضد حساسیت',
      width: '۱۴۵ سانتی‌متر',
      suitableFor: ['کت مجلسی مزونی', 'مانتو عروس و فرمالیته', 'دامن پفی مجلسی'],
      season: ['بهاره', 'پاییزه', 'چهارفصل'],
      stretch: 'بدون کش',
      drape: 'آهاردار و شق‌ورق',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'فقط خشکشویی جهت محافظت از بافت برجسته و درخشش سیم'
    },
    description: 'ژاکارد پفکی فوق‌لوکس با درخشش سیم‌های نقره‌ای که در نور جشن‌ها و مجالس جلوه‌ای استثنایی خلق می‌کند.',
    recommendedGarments: [
      { name: 'کت تک مجلسی', suggestedMeters: '۱.۶۰ متر' },
      { name: 'دامن کلوش مجلسی', suggestedMeters: '۲.۰۰ متر' }
    ]
  },
  {
    id: 'AV-109',
    name: 'لینن چاپی بوهمین طرح گلریز وینتیج',
    category: 'linen',
    categoryName: 'لینن و کتان',
    pattern: 'طرح‌دار',
    pricePerMeter: 360000,
    widthCm: 145,
    images: [
      'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'رز وانیلی', hex: '#E8D3C6' },
      { name: 'سبز مریم‌گلی', hex: '#A3B18A' },
      { name: 'خردلی سنتی', hex: '#D4A373' }
    ],
    tags: ['جدید', 'پرفروش'],
    inStock: true,
    specs: {
      material: 'کتان پنبه ارگانیک با چاپ دیجیتال راکتیو ثابت',
      width: '۱۴۵ سانتی‌متر',
      suitableFor: ['پیراهن وینتیج', 'شومیز تابستانه', 'ساحلی بنددار', 'کیمونو'],
      season: ['بهاره', 'تابستانه'],
      stretch: 'بدون کش',
      drape: 'ایستایی متوسط و لطیف',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'چروک‌پذیری طبیعی کتان',
      shrinkage: 'حدود ۱ الی ۲ درصد آبرفت',
      careInstructions: 'شستشو با آب سرد ۳۰ درجه، استفاده از مایع بدون سفیدکننده'
    },
    description: 'چاپ گل‌های بهاری لطیف روی زمینه طبیعی لینن کتان. مناسب استایل‌های بوهو و پیراهن‌های تابستانه رمانتیک.',
    recommendedGarments: [
      { name: 'پیراهن کلوش بوهمین', suggestedMeters: '۲.۸۰ متر' },
      { name: 'شومیز بهاره گلدار', suggestedMeters: '۱.۵۰ متر' }
    ]
  },
  {
    id: 'AV-110',
    name: 'ساتن سیلک الگانس طرح ماربل و آبرنگی',
    category: 'satin',
    categoryName: 'ساتن',
    pattern: 'طرح‌دار',
    pricePerMeter: 510000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'ماربل کرم و قهوه‌ای', hex: '#A68A78' },
      { name: 'آبرنگی طوسی و صورتی', hex: '#C2A3B5' },
      { name: 'ماربل مشکی و طلا', hex: '#333333' }
    ],
    tags: ['جدید', 'پیشنهاد ویژه'],
    inStock: true,
    specs: {
      material: 'ساتن ابریشم با گرماژ ۱۱۰ گرمی و لمس لغزنده',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['شومیز لوکس', 'تاپ یقه دراپه', 'پیراهن اسلیپ', 'کیمونو مجلسی'],
      season: ['بهاره', 'تابستانه', 'چهارفصل'],
      stretch: 'بدون کش',
      drape: 'ریزش‌دار و لخت',
      sheerness: 'کاملاً پوشیده (بدون نیاز به آستر)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'شستشوی دستی با مایع ابریشم، اتوکشی از پشت پارچه'
    },
    description: 'طرح‌های انتزاعی ماربل با درخشش ساتن اعلا؛ برای خانم‌هایی که به دنبال لباس‌های چشم‌نواز و مدرن هستند.',
    recommendedGarments: [
      { name: 'شومیز یقه شل یا دراپه', suggestedMeters: '۱.۴۰ متر' },
      { name: 'پیراهن اسلیپ ماکسی', suggestedMeters: '۲.۰۰ متر' }
    ]
  },
  {
    id: 'AV-111',
    name: 'کرپ حریر طرح‌دار پلنگی ملایم',
    category: 'crepe',
    categoryName: 'کرپ',
    pattern: 'طرح‌دار',
    pricePerMeter: 320000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1520006403909-838d6b92c22e?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'پلنگی شتری نود', hex: '#BFA588' },
      { name: 'پلنگی طوسی مشکی', hex: '#595959' }
    ],
    tags: ['پرفروش'],
    inStock: true,
    specs: {
      material: 'کرپ شیفون متراکم',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['شومیز مجلسی', 'پیراهن کمردار', 'دامن میدی', 'روپوش بهاره'],
      season: ['بهاره', 'تابستانه', 'پاییزه'],
      stretch: 'بدون کش',
      drape: 'ریزش‌دار و لخت',
      sheerness: 'نیمه شفاف (برای لباس نیازمند زیرپوش یا آستر سبک)',
      wrinkleResistance: 'بسیار مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'شستشو با ماشین در دور کم، عدم چروک‌پذیری بعد از شستن'
    },
    description: 'پترن همیشه ترند پلنگی با هارمونی رنگ‌های خنثی و بافت سبک کرپ حریر که اندام را کشیده‌تر و شیک‌تر نشان می‌دهد.',
    recommendedGarments: [
      { name: 'شومیز ترند زنانه', suggestedMeters: '۱.۴۰ متر' },
      { name: 'دامن کلوش لخت', suggestedMeters: '۱.۸۰ متر' }
    ]
  },
  {
    id: 'AV-112',
    name: 'اورگانزا شیشه‌ای کره‌ای شاین‌دار',
    category: 'silk',
    categoryName: 'حریر و اورگانزا',
    pattern: 'ساده',
    pricePerMeter: 240000,
    widthCm: 150,
    images: [
      'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1000&q=80'
    ],
    colors: [
      { name: 'یاسی هفت‌رنگ', hex: '#E0BBE4' },
      { name: 'شاین یخی', hex: '#EBF4F6' },
      { name: 'طلایی شاین', hex: '#ECD599' }
    ],
    tags: ['جدید'],
    inStock: true,
    specs: {
      material: 'الیاف فیلامنت شیشه‌ای کره‌ای با شاین ثابت',
      width: '۱۵۰ سانتی‌متر',
      suitableFor: ['رویه مانتو', 'آستین پفکی مزونی', 'شنل مجلسی', 'پفی زیر دامن'],
      season: ['بهاره', 'تابستانه'],
      stretch: 'بدون کش',
      drape: 'آهاردار و شق‌ورق',
      sheerness: 'شفاف و بدن‌نما',
      wrinkleResistance: 'مقاوم در برابر چروک',
      shrinkage: 'بدون آبرفت',
      careInstructions: 'اتوکشی غیرمستقیم با حرارت بسیار کم'
    },
    description: 'اورگانزای براق کره‌ای با ایستایی جذاب، گزینه‌ای بی‌رقیب برای طراحی آستین‌های حجم‌دار و روپوش‌های مزونی خاص.',
    recommendedGarments: [
      { name: 'رویه مانتویی مزونی', suggestedMeters: '۲.۰۰ متر' },
      { name: 'خرج‌کار و آستین پفی', suggestedMeters: '۰.۸۰ تا ۱ متر' }
    ]
  }
];
